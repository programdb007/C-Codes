﻿
namespace DuplicateFinder
{
    internal class FileContents
    {
        public string FilePath { get; set; }
        public byte[] Content { get; set; }
    }
}
