﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;

namespace DuplicateFinder
{
    class Program
    {
        static void Main(string[] args)
        {
            bool recurseIntoSubdirectories = false;

            if (args.Length < 1)
            {
                ShowUsage();
                return;
            }

            int firstDirectoryIndex = 0;
            IEnumerable<string> directoriesToSearch = null;
            bool testDirectoriesMade = false;

            // Check to see if we are running in test mode
            if (args.Length == 1 && args[0] == "/test")
            {
                directoriesToSearch = MakeTestDirectories();
                testDirectoriesMade = true;
                recurseIntoSubdirectories = true;
            }
            else
            {
                if (args.Length > 1)
                {
                    // see if we're being asked to recurse
                    if (args[0] == "/sub")
                    {
                        if (args.Length < 2)
                        {
                            ShowUsage();
                            return;
                        }
                        recurseIntoSubdirectories = true;
                        firstDirectoryIndex = 1;
                    }
                }

                // Get list of directories from command line.
                directoriesToSearch = args.Skip(firstDirectoryIndex);
            }

            try
            {
                List<FileNameGroup> filesGroupedByName =
                    InspectDirectories(recurseIntoSubdirectories, directoriesToSearch);

                DisplayMatches(filesGroupedByName);
                Console.ReadKey();
            }
            catch (PathTooLongException ptlx)
            {
                Console.WriteLine("The specified path was too long");
                Console.WriteLine(ptlx.Message);
            }
            catch (DirectoryNotFoundException dnfx)
            {
                Console.WriteLine("The specified directory was not found");
                Console.WriteLine(dnfx.Message);
            }
            catch (IOException iox)
            {
                Console.WriteLine(iox.Message);
            }
            catch (UnauthorizedAccessException uax)
            {
                Console.WriteLine("You do not have permission to access this directory.");
                Console.WriteLine(uax.Message);
            }
            catch (ArgumentException ax)
            {
                Console.WriteLine("The path provided was not valid.");
                Console.WriteLine(ax.Message);
            }
            finally
            {
                if (testDirectoriesMade)
                {
                    CleanupTestDirectories(directoriesToSearch);
                }
            }
        }

        private static void ShowUsage()
        {
            Console.WriteLine("Find duplicate files");
            Console.WriteLine("====================");
            Console.WriteLine(
                "Looks for possible duplicate files in one or more directories");
            Console.WriteLine();
            Console.WriteLine(
                "Usage: findduplicatefiles [/sub] DirectoryName [DirectoryName] ...");
            Console.WriteLine("/sub - recurse into subdirectories");
            Console.ReadKey();
        }

        private static List<FileNameGroup> InspectDirectories(
            bool recurseIntoSubdirectories,
            IEnumerable<string> directoriesToSearch)
        {
            var searchOption = recurseIntoSubdirectories ?
                SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;

            // Get the path of every file in every directory we're searching.

            var allFilePaths = from directory in directoriesToSearch
                               from file in GetDirectoryFiles(directory,
                                                              searchOption)
                               select file;

            // Group the files by local filename (i.e. the filename without the
            // containing path), and for each filename, build a list containing the
            // details for every file that has that filename.

            var fileNameGroups = from filePath in allFilePaths
                                 let fileNameWithoutPath = Path.GetFileName(filePath)
                                 group filePath by fileNameWithoutPath into nameGroup
                                 select new FileNameGroup
                                 {
                                     FileNameWithoutPath = nameGroup.Key,
                                     FilesWithThisName = GetDetails(nameGroup).ToList()
                                 };

            return fileNameGroups.ToList();
        }

        private static void DisplayMatches(
            IEnumerable<FileNameGroup> filesGroupedByName)
        {
            var groupsWithMoreThanOneFile = from nameGroup in filesGroupedByName
                                            where nameGroup.FilesWithThisName.Count > 1
                                            select nameGroup;

            foreach (var fileNameGroup in groupsWithMoreThanOneFile)
            {
                // Group the matches by the file size, then select those
                // with more than 1 file of that size.
                var matchesBySize = from file in fileNameGroup.FilesWithThisName
                                    group file by file.FileSize into sizeGroup
                                    where sizeGroup.Count() > 1
                                    select sizeGroup;

                foreach (var matchedBySize in matchesBySize)
                {
                    string fileNameAndSize = string.Format("{0} ({1} bytes)",
                    fileNameGroup.FileNameWithoutPath, matchedBySize.Key);
                    WriteWithUnderlines(fileNameAndSize);

                    // Show each of the directories containing this file
                    {
                        List<FileContents> content = LoadFiles(matchedBySize);
                        CompareFiles(content);
                    }
                    Console.WriteLine();
                }
            }
        }

        private static List<FileContents> LoadFiles(IEnumerable<FileDetails> fileList)
        {
            var content = new List<FileContents>();
            foreach (FileDetails item in fileList)
            {
                byte[] contents = ReadAllBytes(item.FilePath);
                content.Add(new FileContents
                {
                    FilePath = item.FilePath,
                    Content = contents
                });
            }
            return content;
        }

        private static void CompareFiles(List<FileContents> files)
        {
            Dictionary<FileContents, List<FileContents>> potentiallyMatched =
            BuildPotentialMatches(files);

            // Now, we're going to look at every byte in each
            CompareBytes(files, potentiallyMatched);

            DisplayResults(files, potentiallyMatched);
        }

        private static Dictionary<FileContents, List<FileContents>>
            BuildPotentialMatches(List<FileContents> files)
        {
            // Builds a dictionary where the entries look like:
            // { 0, { 1, 2, 3, 4, ... N } }
            // { 1, { 2, 3, 4, ... N }
            // ...
            // { N - 1, { N } }
            // where N is one less than the number of files.
            var allCombinations = Enumerable.Range(0, files.Count - 1).ToDictionary(
                x => files[x],
            x => files.Skip(x + 1).ToList());

            return allCombinations;
        }

        private static void DisplayResults(
            List<FileContents> files,
            Dictionary<FileContents, List<FileContents>> currentlyMatched)
        {
            if (currentlyMatched.Count == 0) { return; }

            var alreadyMatched = new List<FileContents>();

            Console.WriteLine("Matches");

            foreach (var matched in currentlyMatched)
            {
                // Don't do it if we've already matched it previously
                if (alreadyMatched.Contains(matched.Key))
                {
                    continue;
                }
                else
                {
                    alreadyMatched.Add(matched.Key);
                }
                Console.WriteLine("-------");
                Console.WriteLine(matched.Key.FilePath);
                foreach (var file in matched.Value)
                {
                    Console.WriteLine(file.FilePath);
                    alreadyMatched.Add(file);
                }
            }
            Console.WriteLine("-------");
        }

        private static void CompareBytes(
            List<FileContents> files,
            Dictionary<FileContents, List<FileContents>> potentiallyMatched)
        {
            // Remember, this only ever gets called with files of equal length.
            int fileLength = files[0].Content.Length;
            var sourceFilesWithNoMatches = new List<FileContents>();
            for (int fileByteOffset = 0; fileByteOffset < fileLength; ++fileByteOffset)
            {
                foreach (var sourceFileEntry in potentiallyMatched)
                {
                    byte[] sourceContent = sourceFileEntry.Key.Content;
                    for (int otherIndex = 0; otherIndex < sourceFileEntry.Value.Count;
                    ++otherIndex)
                    {
                        // Check the byte at i in each of the two files, if they don't
                        // match, then we remove them from the collection
                        byte[] otherContent =
                        sourceFileEntry.Value[otherIndex].Content;
                        if (sourceContent[fileByteOffset] != otherContent[fileByteOffset])
                        {
                            sourceFileEntry.Value.RemoveAt(otherIndex);
                            otherIndex -= 1;
                            if (sourceFileEntry.Value.Count == 0)
                            {
                                sourceFilesWithNoMatches.Add(sourceFileEntry.Key);
                            }
                        }
                    }
                }
                foreach (FileContents fileWithNoMatches in sourceFilesWithNoMatches)
                {
                    potentiallyMatched.Remove(fileWithNoMatches);
                }
                // Don't bother with the rest of the file if
                // there are no further potential matches
                if (potentiallyMatched.Count == 0)
                {
                    break;
                }
                sourceFilesWithNoMatches.Clear();
            }
        }

        private static void WriteWithUnderlines(string text)
        {
            Console.WriteLine(text);
            Console.WriteLine(new string('-', text.Length));
        }

        private static string[] MakeTestDirectories()
        {
            string localApplicationData = Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData),
                @"Programming CSharp\FindDuplicates");

            // Get the name of the logged in user
            string userName = WindowsIdentity.GetCurrent().Name;
            // Make the access control rule
            FileSystemAccessRule fsarAllow =
                new FileSystemAccessRule(
                    userName,
                    FileSystemRights.FullControl,
                    AccessControlType.Allow);
            DirectorySecurity ds = new DirectorySecurity();
            ds.AddAccessRule(fsarAllow);

            FileSystemAccessRule fsarDeny =
                new FileSystemAccessRule(
                    userName,
                    FileSystemRights.WriteExtendedAttributes,
                    AccessControlType.Deny);
            ds.AddAccessRule(fsarDeny);

            // Let's make three test directories
            // and leave space for a fourth to test access denied behavior
            var directories = new string[4];
            for (int i = 0; i < directories.Length - 1; ++i)
            {
                string directory = Path.GetRandomFileName();
                // Combine the local application data with the
                // new random file/directory name
                string fullPath = Path.Combine(localApplicationData, directory);
                // And create the directory
                Directory.CreateDirectory(fullPath, ds);
                directories[i] = fullPath;
                Console.WriteLine(fullPath);
            }

            CreateTestFiles(directories.Take(3));

            directories[3] = CreateDeniedDirectory(localApplicationData);

            return directories;
        }

        private static void CleanupTestDirectories(IEnumerable<string> directories)
        {
            foreach (var directory in directories)
            {
                AllowAccess(directory);
                Directory.Delete(directory, true);
            }
        }

        private static void CreateTestFiles(IEnumerable<string> directories)
        {
            string fileForAllDirectories = "SameNameAndContent.txt";
            string fileSameInAllButDifferentSizes = "SameNameDifferentSize.txt";
            string fileSameSizeInAllButDifferentContent =
                "SameNameAndSizeDifferentContent.txt";

            int directoryIndex = 0;
            // Let's create a distinct file that appears in each directory
            foreach (string directory in directories)
            {
                directoryIndex++;

                // Create the distinct file for this directory
                string filename = Path.GetRandomFileName();
                string fullPath = Path.Combine(directory, filename);
                CreateFile(fullPath, "Example content 1");

                // And now the one that is in all directories, with the same content
                fullPath = Path.Combine(directory, fileForAllDirectories);
                CreateFile(fullPath, "Found in all directories");

                // And now the one that has the same name in
                // all directories, but with different sizes
                fullPath = Path.Combine(directory, fileSameInAllButDifferentSizes);
                StringBuilder builder = new StringBuilder();
                builder.AppendLine("Now with");
                builder.AppendLine(new string('x', directoryIndex));
                CreateFile(fullPath, builder.ToString());

                // And now one that is the same length, but with different content
                fullPath = Path.Combine(directory, fileSameSizeInAllButDifferentContent);
                builder = new StringBuilder();
                builder.Append("Now with ");
                builder.Append(directoryIndex);
                builder.AppendLine(" extra");
                CreateFile(fullPath, builder.ToString());
            }
        }

        private static void CreateFile(string fullPath, string contents)
        {
            File.WriteAllText(fullPath, contents);
        }

        static void DoubtfulCode()
        {
            if (File.Exists("SomeFile.txt"))
            {
                // Play with the file
            }
        }

        private static string CreateDeniedDirectory(string parentPath)
        {
            string deniedDirectory = Path.GetRandomFileName();
            string fullDeniedPath = Path.Combine(parentPath, deniedDirectory);
            string userName = WindowsIdentity.GetCurrent().Name;
            DirectorySecurity ds = new DirectorySecurity();
            FileSystemAccessRule fsarDeny =
                new FileSystemAccessRule(
                    userName,
                    FileSystemRights.ListDirectory,
                    AccessControlType.Deny);
            ds.AddAccessRule(fsarDeny);

            Directory.CreateDirectory(fullDeniedPath, ds);
            return fullDeniedPath;
        }

        private static void AllowAccess(string directory)
        {
            DirectorySecurity ds = Directory.GetAccessControl(directory);

            string userName = WindowsIdentity.GetCurrent().Name;

            // Remove the deny rule
            FileSystemAccessRule fsarDeny =
                new FileSystemAccessRule(
                    userName,
                    FileSystemRights.ListDirectory,
                    AccessControlType.Deny);
            ds.RemoveAccessRuleSpecific(fsarDeny);

            // And add an allow rule
            FileSystemAccessRule fsarAllow =
                new FileSystemAccessRule(
                    userName,
                    FileSystemRights.FullControl,
                    AccessControlType.Allow);
            ds.AddAccessRule(fsarAllow);

            Directory.SetAccessControl(directory, ds);
        }

        private static IEnumerable<string> GetDirectoryFiles(
            string directory, SearchOption searchOption)
        {
            try
            {
                return Directory.GetFiles(directory, "*.*", searchOption);
            }
            catch (DirectoryNotFoundException dnfx)
            {
                Console.WriteLine("Warning: The specified directory was not found");
                Console.WriteLine(dnfx.Message);
            }
            catch (UnauthorizedAccessException uax)
            {
                Console.WriteLine(
                "Warning: You do not have permission to access this directory.");
                Console.WriteLine(uax.Message);
            }
            return Enumerable.Empty<string>();
        }

        private static IEnumerable<FileDetails> GetDetails(IEnumerable<string> paths)
        {
            foreach (string filePath in paths)
            {
                FileDetails details = null;
                try
                {
                    FileInfo info = new FileInfo(filePath);
                    details = new FileDetails
                    {
                        FilePath = filePath,
                        FileSize = info.Length
                    };
                }
                catch (FileNotFoundException fnfx)
                {
                    Console.WriteLine("Warning: The specified file was not found");
                    Console.WriteLine(fnfx.Message);
                }
                catch (IOException iox)
                {
                    Console.Write("Warning: ");
                    Console.WriteLine(iox.Message);
                }
                catch (UnauthorizedAccessException uax)
                {
                    Console.WriteLine(
                "Warning: You do not have permission to access this file.");
                    Console.WriteLine(uax.Message);
                }
                if (details != null)
                {
                    yield return details;
                }
            }
        }

        // Example 11-40. Reading from a stream
        private static byte[] ReadAllBytes(string filename)
        {
            using (FileStream stream = File.OpenRead(filename))
            {
                long streamLength = stream.Length;
                if (streamLength > 0x7fffffffL)
                {
                    throw new InvalidOperationException(
                    "Unable to allocate more than 0x7fffffffL bytes" +
                    "of memory to read the file");
                }
                // Safe to cast to an int, because
                // we checked for overflow above
                int bytesToRead = (int)stream.Length;
                // This could be a big buffer!
                byte[] bufferToReturn = new byte[bytesToRead];
                // We're going to start at the beginning
                int offsetIntoBuffer = 0;
                while (bytesToRead > 0)
                {
                    int bytesRead = stream.Read(bufferToReturn,
                    offsetIntoBuffer,
                    bytesToRead);
                    if (bytesRead == 0)
                    {
                        throw new InvalidOperationException(
                        "We reached the end of file before we expected..." +
                        "Has someone changed the file while we weren't looking?");
                    }
                    // Read may return fewer bytes than we asked for, so be
                    // ready to go round again.
                    bytesToRead -= bytesRead;
                    offsetIntoBuffer += bytesRead;
                }
                return bufferToReturn;
            }
        }
    }
}
