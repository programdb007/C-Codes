﻿using System;
using System.IO;

namespace SetDirectory
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 11-6. Setting the current directory
            Directory.SetCurrentDirectory(@"c:\");

            foreach (var user in Directory.GetDirectories("Users"))
            {
                Console.WriteLine(user);
            }
        }
    }
}
