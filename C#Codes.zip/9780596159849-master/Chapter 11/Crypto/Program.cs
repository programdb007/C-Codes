﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace Crypto
{
    class Program
    {
        // Example 11-51. Using an encryption stream
        static void Main(string[] args)
        {
            byte[] key;
            byte[] iv;
            // Get the appropriate key and initialization vector for the algorithm
            SelectKeyAndIV(out key, out iv);
            string superSecret = "This is super secret";
            Console.WriteLine(superSecret);
            string encryptedText = EncryptString(superSecret, key, iv);
            Console.WriteLine(encryptedText);
            string decryptedText = DecryptString(encryptedText, key, iv);
            Console.WriteLine(decryptedText);
            Console.ReadKey();
        }

        // Example 11-52. Creating a key and IV
        private static void SelectKeyAndIV(out byte[] key, out byte[] iv)
        {
            var algorithm = TripleDES.Create();
            algorithm.GenerateIV();
            algorithm.GenerateKey();
            key = algorithm.Key;
            iv = algorithm.IV;
        }

        // Example 11-53. Encrypting a string
        private static string EncryptString(string plainText, byte[] key, byte[] iv)
        {
            // Create a crypto service provider for the TripleDES algorithm
            var serviceProvider = new TripleDESCryptoServiceProvider();

            using (MemoryStream memoryStream = new MemoryStream())
            using (var cryptoStream = new CryptoStream(
                                            memoryStream,
                                            serviceProvider.CreateEncryptor(key, iv),
                                            CryptoStreamMode.Write))
            using (StreamWriter writer = new StreamWriter(cryptoStream))
            {
                // Write some text to the crypto stream, encrypting it on the way
                writer.Write(plainText);
                // Make sure that the writer has flushed to the crypto stream
                writer.Flush();
                // We also need to tell the crypto stream to flush the final block out to
                // the underlying stream, or we'll
                // be missing some content...
                cryptoStream.FlushFinalBlock();

                // Now, we want to get back whatever the crypto stream wrote to our memory
                // stream.
                return GetCipherText(memoryStream);
            }
        }

        // Example 11-54. Converting to Base64
        private static string GetCipherText(MemoryStream memoryStream)
        {
            byte[] buffer = memoryStream.ToArray();
            return System.Convert.ToBase64String(buffer, 0, buffer.Length);
        }

        // Example 11-55. Decryption
        private static string DecryptString(string cipherText, byte[] key, byte[] iv)
        {
            // Create a crypto service provider for the TripleDES algorithm
            var serviceProvider = new TripleDESCryptoServiceProvider();

            // Decode the cipher-text bytes back from the base-64 encoded string
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);

            // Create a memory stream over those bytes
            using (MemoryStream memoryStream = new MemoryStream(cipherTextBytes))
            // And create a cryptographic stream over the memory stream,
            // using the specified algorithm
            // (with the provided key and initialization vector)
            using (var cryptoStream =
                new CryptoStream(
                    memoryStream,
                    serviceProvider.CreateDecryptor(key, iv),
                    CryptoStreamMode.Read))
            // Finally, create a stream reader over the stream, and recover the
            // original text
            using (StreamReader reader = new StreamReader(cryptoStream))
            {
                return reader.ReadToEnd();
            }
        }
    }
}
