﻿
namespace DuplicateFinder
{
    // Example 11-3 (part 2). Types used to keep track of the files we’ve found
    class FileDetails
    {
        public string FilePath { get; set; }
        public long FileSize { get; set; }
    }
}
