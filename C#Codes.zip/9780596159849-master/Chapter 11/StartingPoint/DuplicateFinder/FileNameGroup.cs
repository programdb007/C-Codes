﻿using System.Collections.Generic;

namespace DuplicateFinder
{
    // Example 11-3 (part 1). Types used to keep track of the files we’ve found
    class FileNameGroup
    {
        public string FileNameWithoutPath { get; set; }
        public List<FileDetails> FilesWithThisName { get; set; }
    }
}
