﻿using System;
using System.IO;
using System.IO.IsolatedStorage;

namespace Isolated
{
    class Program
    {
        // Example 11-49. Creating folders and files in a store
        static void Main(string[] args)
        {
            IsolatedStorageFile store = IsolatedStorageFile.GetUserStoreForAssembly();
            // Create a directory - safe to call multiple times
            store.CreateDirectory("Settings");
            // Open or create the file
            using (IsolatedStorageFileStream stream = store.OpenFile(
                "Settings\\standardsettings.txt",
                System.IO.FileMode.OpenOrCreate,
                System.IO.FileAccess.ReadWrite))
            {
                UseStream(stream);
            }
            Console.ReadKey();
        }

        // Example 11-50. Using StreamReader and StreamWriter with isolated storage
        static void UseStream(Stream stream)
        {
            if (stream.Length > 0)
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    Console.WriteLine(reader.ReadToEnd());
                }
            }
            else
            {
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.WriteLine(
                    "Initialized settings at {0}", DateTime.Now.TimeOfDay);
                    Console.WriteLine("Settings have been initialized");
                }
            }
        }
    }
}
