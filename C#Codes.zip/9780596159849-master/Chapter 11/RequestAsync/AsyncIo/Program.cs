﻿using System;
using System.IO;

namespace AsyncIo
{
    class Program
    {
        // Example 11-47. Asynchronous file I/O
        static void Main(string[] args)
        {
            string path = "mytestfile.txt";
            // Create a test file
            using (var file = File.Create(path, 4096, FileOptions.Asynchronous))
            {
                // Some bytes to write
                byte[] myBytes = new byte[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
                IAsyncResult asyncResult = file.BeginWrite(
                    myBytes,
                    0,
                    myBytes.Length,
                    // A callback function, written as an anonymous delegate
                    delegate(IAsyncResult result)
                    {
                        // You *must* call EndWrite() exactly once
                        file.EndWrite(result);
                        // Then do what you like
                        Console.WriteLine(
                        "Called back on thread {0} when the operation completed",
                        System.Threading.Thread.CurrentThread.ManagedThreadId);
                    },
                    null);

                // You could do something else while you waited...
                Console.WriteLine(
                    "Waiting on thread {0}...",
                    System.Threading.Thread.CurrentThread.ManagedThreadId);
                // Waiting on the main thread
                asyncResult.AsyncWaitHandle.WaitOne();
                Console.WriteLine(
                    "Completed {0} on thread {1}...",
                    asyncResult.CompletedSynchronously ?
                        "synchronously" : "asynchronously",
                    System.Threading.Thread.CurrentThread.ManagedThreadId);
                Console.ReadKey();
                return;
            }
        }
    }
}
