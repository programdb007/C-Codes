﻿using System.IO;

namespace DuplicateFinder
{
    // Example 11-41. FileContents using FileStream
    internal class FileContents
    {
        public string FilePath { get; set; }
        public FileStream Content { get; set; }
    }
}
