﻿using System.Collections.Generic;

namespace DuplicateFinder
{
    class FileNameGroup
    {
        public string FileNameWithoutPath { get; set; }
        public List<FileDetails> FilesWithThisName { get; set; }
    }
}
