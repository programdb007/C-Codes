﻿
namespace DuplicateFinder
{
    // Example 11-34. File content information class
    internal class FileContents
    {
        public string FilePath { get; set; }
        public byte[] Content { get; set; }
    }
}
