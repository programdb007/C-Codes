﻿
namespace DuplicateFinder
{
    class FileDetails
    {
        public string FilePath { get; set; }
        public long FileSize { get; set; }
    }
}
