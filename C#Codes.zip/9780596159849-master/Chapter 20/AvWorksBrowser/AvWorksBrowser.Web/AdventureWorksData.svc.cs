﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Data.Services.Common;
using System.Linq;
using System.ServiceModel.Web;
using System.Web;

namespace AvWorksBrowser.Web
{
    public class AdventureWorksData : DataService<AdventureWorksLT2008Entities>
    {
        public static void InitializeService(DataServiceConfiguration config)
        {
            config.SetEntitySetAccessRule("Products", EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("ProductCategories", EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("ProductDescriptions", EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("ProductModels", EntitySetRights.AllRead);

            config.DataServiceBehavior.MaxProtocolVersion = DataServiceProtocolVersion.V2;
        }
    }
}
