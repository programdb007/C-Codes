﻿using System;
using System.Linq;
using AvWorksBrowser.AdvWorksData;
using System.Collections.Generic;

namespace AvWorksBrowser
{
    public class CategoryViewModel
    {
        private ProductCategory entity;

        private CategoryViewModel(ProductCategory categoryEntity)
        {
            entity = categoryEntity;
        }

        public static void GetCategories(Action<IList<CategoryViewModel>> categoriesFetchedCallback)
        {
            Uri dataUri = new Uri(App.Current.Host.Source, "/AdventureWorksData.svc");
            AdventureWorksLT2008Entities dataServiceContext = new AdventureWorksLT2008Entities(dataUri);

            // The Expand("Product") says "oh while you're there, get all the related Product entities".
            // It is similar to (and mysteriously named inconsistently with) the EF's Include method.

            // We should be able to filter on available products, but this is what we get
            // when writing a suitable LINQ query:
            // ProductCategory()?$filter=Product/Count gt 0&$expand=Products
            // And ADO.NET DS gives us a 404 because it doesn't know what
            // Product/Count is. So we have to filter client side once we
            // get the results.
            var q = dataServiceContext.ProductCategories.Expand("Products");
            q.BeginExecute(delegate(IAsyncResult iar)
            {
                var categories = q.EndExecute(iar);
                var categoryViewModels = from category in categories
                                         where category.Products.Count > 0
                                         select new CategoryViewModel(category);

                categoriesFetchedCallback(categoryViewModels.ToArray());
            }, null);

        }

        public string DisplayName { get { return entity.Name; } }

        private ProductViewModel[] cachedProducts;

        public IList<ProductViewModel> Products
        {
            get
            {
                if (cachedProducts == null)
                {
                    cachedProducts = (from product in entity.Products
                                      select new ProductViewModel(product)).ToArray();
                }

                return cachedProducts;
            }
        }

    }
}
