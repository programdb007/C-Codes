﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using AvWorksBrowser.AdvWorksData;

namespace AvWorksBrowser
{
    public class ProductViewModel
    {
        private Product entity;

        public ProductViewModel(Product productEntity)
        {
            entity = productEntity;
        }

        public string DisplayName { get { return entity.Name; } }


        public Uri Thumbnail
        {
            get
            {
                return new Uri(App.Current.Host.Source,
                    string.Format("/ProductThumbnail.ashx?id={0}", entity.ProductID));
            }
        }

    }
}
