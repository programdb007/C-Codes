﻿using System.Collections.Generic;
using System.Windows.Controls;

namespace AvWorksBrowser
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            CategoryViewModel.GetCategories(delegate(IList<CategoryViewModel> categoryViewModels)
            {
                // Example 20-29. Providing items for a listbox
                categoryList.ItemsSource = categoryViewModels;
            });
        }

        // Example 20-30. Loading the selected category’s products
        private void categoryList_SelectionChanged(object sender,
        SelectionChangedEventArgs e)
        {
            CategoryViewModel currentCategory =
            categoryList.SelectedItem as CategoryViewModel;
            if (currentCategory == null)
            {
                productList.ItemsSource = null;
            }
            else
            {
                productList.ItemsSource = currentCategory.Products;
            }
        }
    }
}
