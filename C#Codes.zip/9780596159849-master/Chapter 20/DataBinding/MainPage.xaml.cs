﻿using System.Windows.Controls;

namespace DataBinding
{
    // Example 20-27. Setting up a data source
    public partial class MainPage : UserControl
    {
        private Person source = new Person { Name = "Ian", Age = 36 };
        public MainPage()
        {
            InitializeComponent();
            this.DataContext = source;
        }
    }
}
