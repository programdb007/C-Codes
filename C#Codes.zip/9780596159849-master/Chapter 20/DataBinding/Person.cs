﻿
namespace DataBinding
{
    // Example 20-26. A very simple data source
    public class Person
    {
        public string Name { get; set; }
        public double Age { get; set; }
    }
}
