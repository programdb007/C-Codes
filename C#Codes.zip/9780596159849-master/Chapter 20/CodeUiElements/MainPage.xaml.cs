﻿using System.Windows;
using System.Windows.Controls;

namespace CodeUiElements
{
    // Example 20-3. Creating UI elements in code
    public partial class MainPage : UserControl
    {
        private Button myButton;
        private TextBlock messageText;
        public MainPage()
        {
            InitializeComponent();
            myButton = new Button
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Top,
                FontSize = 20,
                Content = "Click me!"
            };
            myButton.Click += new RoutedEventHandler(myButton_Click);
            messageText = new TextBlock
            {
                Text = "Message will appear here",
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                FontSize = 30,
                FontWeight = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            LayoutRoot.Children.Add(myButton);
            LayoutRoot.Children.Add(messageText);
        }

        void myButton_Click(object sender, RoutedEventArgs e)
        {
            messageText.Text = "Hello, world!";
        }
    }
}
