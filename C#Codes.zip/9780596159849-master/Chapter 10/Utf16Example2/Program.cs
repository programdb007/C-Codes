﻿using System;
using System.Text;

namespace Utf16Example2
{
    class Program
    {
        // Example 10-84. Showing byte values of encoded text
        static void Main(string[] args)
        {
            string listenUpFR = "Écoute-moi!";
            
            byte[] utf16Bytes = Encoding.Unicode.GetBytes(listenUpFR);
            // or...
            // Example 10-85. Using big-endian UTF-16
            //byte[] utf16Bytes = Encoding.BigEndianUnicode.GetBytes(listenUpFR);

            Console.WriteLine("UTF-16");
            Console.WriteLine("-----");
            foreach (var encodedByte in utf16Bytes)
            {
                Console.Write(string.Format("{0:X2}", encodedByte));
                Console.Write(" ");
            }
            Console.ReadKey();
        }
    }
}
