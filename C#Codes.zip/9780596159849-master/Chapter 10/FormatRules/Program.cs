﻿using System;
using System.Globalization;

namespace FormatRules
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 10-48. Modifying the decimal separator
            double value = 1.8;
            NumberFormatInfo nfi = new NumberFormatInfo();
            nfi.NumberDecimalSeparator = "^";
            Console.WriteLine(value.ToString(nfi));
        }
    }
}
