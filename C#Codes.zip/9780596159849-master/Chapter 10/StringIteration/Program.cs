﻿using System;

namespace StringIteration
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 10-1. Iterating through the characters in a string
            string myString = "I've gone all vertical.";
            foreach (char theCharacter in myString)
            {
                Console.WriteLine(theCharacter);
            }
        }
    }
}
