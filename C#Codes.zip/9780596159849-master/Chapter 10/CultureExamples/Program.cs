﻿using System;
using System.Globalization;
using System.Linq;

namespace CultureExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 10-46. Showing available cultures
            var cultures = CultureInfo.GetCultures(CultureTypes.AllCultures).
                OrderBy(c => c.EnglishName);
            foreach (var culture in cultures)
            {
                Console.WriteLine("{0} : {1}", culture.EnglishName, culture.Name);
            }

            // Example 10-47. Formatting numbers for different cultures
            CultureInfo englishUS = CultureInfo.CreateSpecificCulture("en-US");
            CultureInfo french = CultureInfo.CreateSpecificCulture("fr");
            double value = 1.8;
            Console.WriteLine(value.ToString(englishUS));
            Console.WriteLine(value.ToString(french));
        }
    }
}
