﻿using System;

namespace Formatting
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                // Example 10-5. Converting numbers to strings with ToString
                int myValue = 45;
                string myString = myValue.ToString();
                Console.WriteLine(myString);
            }

            {
                // Example 10-6. Calling ToString on a decimal
                decimal myValue = 45.65M;
                string myString = myValue.ToString();
                Console.WriteLine(myString);
            }

            {
                // Example 10-7. Currency format
                decimal dollarAmount = 123165.4539M;
                string text = dollarAmount.ToString("C");
                Console.WriteLine(text);
            }

            {
                // Example 10-8. Specifying decimal places with currency format
                decimal dollarAmount = 123165.4539M;
                string text = dollarAmount.ToString("C3");
                Console.WriteLine(text);
            }

            {
                // Example 10-9. Decimal format, with explicit precision
                int amount = 1654539;
                string text = amount.ToString("D9");
                Console.WriteLine(text);
            }

            {
                // Example 10-10. Decimal format with unspecified precision
                int amount = -2895729;
                string text = amount.ToString("D");
                Console.WriteLine(text);
            }

            {
                // Example 10-11. Hexadecimal format
                int amount = 256;
                string text = amount.ToString("X");
                Console.WriteLine(text);
            }

            {
                // Example 10-12. Hexadecimal format with explicit precision
                int amount = 256;
                string text = amount.ToString("X4");
                Console.WriteLine(text);
            }

            {
                // Example 10-13. Exponential format
                double amount = 254.23875839484;
                string text = amount.ToString("E4");
                Console.WriteLine(text);
            }

            {
                // Example 10-14. Exponential format without precision
                double amount = 254.23875839484;
                string text = amount.ToString("E");
                Console.WriteLine(text);
            }

            {
                // Example 10-15. Fixed-point format
                double amount = 152.68385485;
                string text = amount.ToString("F4");
                Console.WriteLine(text);
            }

            {
                // Example 10-16. Fixed-point format causing trailing zeros
                double amount = 152.68;
                string text = amount.ToString("F4");
                Console.WriteLine(text);
            }

            {
                // Example 10-17. General format
                double amount = 152.68;
                string text = amount.ToString("G4");
                Console.WriteLine(text);

                double amount2 = 0.00000000000015268;
                text = amount2.ToString("G4");
                Console.WriteLine(text);
            }

            {
                // Example 10-18. Numeric format
                double amount = 1520494.684848;
                string text = amount.ToString("N4");
                Console.WriteLine(text);
            }

            {
                // Example 10-19. Percent format
                double amount = 0.684848;
                string text = amount.ToString("P4");
                Console.WriteLine(text);
            }

            {
                // Example 10-20. Round-trip format
                double amount = 0.684848;
                string text = amount.ToString("R");
                Console.WriteLine(text);
            }

            {
                // Example 10-21. Custom numeric formats
                double value = 12.3456;
                Console.WriteLine(value.ToString("00.######"));

                value = 1.23456;
                Console.WriteLine(value.ToString("00.000000"));

                Console.WriteLine(value.ToString("##.000000"));
            }

            {
                string text;

                // Example 10-22. Placeholders after the decimal point
                double value = 1234.5678;
                text = value.ToString("#.###");
                Console.WriteLine(text);
            }

            {
                // Example 10-23. Placeholders and leading or trailing zeros
                double value = 0.46;
                string text = value.ToString("#.###");
                Console.WriteLine(text);
            }

            {
                // Example 10-24. Comma for grouping digits
                int value = 12345678;
                string text = value.ToString("#,#");
                Console.WriteLine(text);
            }

            {
                // Example 10-25. Comma for scaling down output
                int value = 12345678;
                string text = value.ToString("#,#,,.");
                Console.WriteLine(text);
            }

            {
                // Example 10-26. Implied decimal point
                int value = 12345678;
                string text = value.ToString("#,#,,");
                Console.WriteLine(text);
            }

            {
                // Example 10-27. Arbitrary text in a custom format string
                int value = 12345678;
                string text = value.ToString("###-### but ###");
                Console.WriteLine(text);
            }

            {
                // Example 10-28. Escaping characters in a custom format string
                int value = 12345678;
                string text = value.ToString("###-### \\# ###");
                Console.WriteLine(text);
            }

            {
                // Example 10-29. @-quoting a custom format string
                int value = 12345678;
                string text = value.ToString(@"###-### \# ###");
                Console.WriteLine(text);
            }

            {
                // Example 10-30. Literal string in a custom format string
                int value = 12345678;
                string text = value.ToString(@"###-### \# ### 'is a number'");
                Console.WriteLine(text);
            }

            {
                // Example 10-31. Percentage in a custom format string
                double value = 0.95;
                string text = value.ToString("#0.##%");
                Console.WriteLine(text);
            }

            {
                // Example 10-32. Preparing to present a DateTimeOffset to the user
                DateTimeOffset tmo = GetTimeFromSomewhere();
                DateTime localDateTime = tmo.ToLocalTime().DateTime;
                Console.WriteLine(localDateTime);
            }

            {
                // Example 10-33. Showing the date in various formats
                DateTime time = new DateTime(2001, 12, 24, 13, 14, 15, 16);
                Console.WriteLine(time.ToString("d"));
                Console.WriteLine(time.ToShortDateString());
                Console.WriteLine(time.ToString("D"));
                Console.WriteLine(time.ToLongDateString());
            }

            {
                // Example 10-34. Getting just the time
                DateTime time = new DateTime(2001, 12, 24, 13, 14, 15, 16);
                Console.WriteLine(time.ToString("t"));
                Console.WriteLine(time.ToShortTimeString());
                Console.WriteLine(time.ToString("T"));
                Console.WriteLine(time.ToLongTimeString());
            }

            {
                // Example 10-35. Getting both the time and date
                DateTime time = new DateTime(2001, 12, 24, 13, 14, 15, 16);
                Console.WriteLine(time.ToString("g"));
                Console.WriteLine(time.ToString("G"));
                Console.WriteLine(time.ToString("f"));
                Console.WriteLine(time.ToString("F"));
            }

            {
                // Example 10-36. Round-trip DateTime format
                DateTime time = new DateTime(2001, 12, 24, 13, 14, 15, 16);
                Console.WriteLine(time.ToString("O"));
            }

            {
                // Example 10-37. Universal sortable format
                DateTime time = new DateTime(2001, 12, 24, 13, 14, 15, 16);
                Console.WriteLine(time.ToString("u"));
            }

            {
                // Example 10-38. Formatting the day
                DateTime time = new DateTime(2001, 12, 24, 13, 14, 15, 16);
                Console.WriteLine(time.ToString("dddd"));
                Console.WriteLine(time.ToString("ddd"));
                Console.WriteLine(time.ToString("dd"));
            }

            {
                // Example 10-39. Converting a string to an int
                int converted = Convert.ToInt32("35");
                Console.WriteLine(converted);
            }

            {
                // Example 10-40. Converting hexadecimal strings to ints
                int converted = Convert.ToInt32("35", 16);
                Console.WriteLine(converted);
                converted = Convert.ToInt32("0xFF", 16);
                Console.WriteLine(converted);
            }

            {
                try
                {
                    // Example 10-41. Attempting to convert a non-numeric string to a number
                    double converted = Convert.ToDouble("Well, what do you think?");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Failed conversion");
                }
            }

            {
                // Example 10-42. Avoiding exceptions with TryParse
                int parsed;
                if (!int.TryParse("Well, how about that", out parsed))
                {
                    Console.WriteLine("That didn't parse");
                }
            }

            {
                // Example 10-43. DateTime.ParseExact
                DateTime dt =
                    DateTime.ParseExact("12^04^2008", "dd^MM^yyyy", System.Globalization.CultureInfo.CurrentCulture);
                Console.WriteLine(dt);
            }
        }

        private static DateTimeOffset GetTimeFromSomewhere()
        {
            return DateTimeOffset.UtcNow;
        }
    }
}
