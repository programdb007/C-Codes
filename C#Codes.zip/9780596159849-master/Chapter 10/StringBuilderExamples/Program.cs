﻿using System;
using System.Text;

namespace StringBuilderExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                // Example 10-65. Capacity versus Length
                StringBuilder builder1 = new StringBuilder();
                StringBuilder builder2 = new StringBuilder(1024);

                Console.WriteLine(builder1.Capacity);
                Console.WriteLine(builder1.Length);

                Console.WriteLine(builder2.Capacity);
                Console.WriteLine(builder1.Length);
            }
            Console.WriteLine();
            {
                // Example 10-66. Exploring capacity
                StringBuilder builder1 = new StringBuilder();
                StringBuilder builder2 = new StringBuilder(1024);

                Console.WriteLine(builder1.Capacity);
                Console.WriteLine(builder1.Length);
                Console.WriteLine(builder2.Capacity);
                Console.WriteLine(builder2.Length);

                builder1.Append('A', 24);
                builder2.Append('A', 24);

                Console.WriteLine(builder1.Capacity);
                Console.WriteLine(builder1.Length);
                Console.WriteLine(builder2.Capacity);
                Console.WriteLine(builder2.Length);


                Console.WriteLine();

                // Example 10-67. Appending more text
                builder1.Append('B', 12);
                Console.WriteLine(builder1.Capacity);
                Console.WriteLine(builder1.Length);


                Console.WriteLine();

                // Example 10-68. Appending yet more text
                builder1.Append('C', 30);
                Console.WriteLine(builder1.Capacity);
                Console.WriteLine(builder1.Length);


                Console.WriteLine();

                // Example 10-69. Ensuring capacity
                builder1.EnsureCapacity(32000);
                Console.WriteLine(builder1.Capacity);
                Console.WriteLine(builder1.Length);


                Console.WriteLine();

                // Example 10-70. Attempting to reduce capacity
                builder1.EnsureCapacity(70);
                Console.WriteLine(builder1.Capacity);
                Console.WriteLine(builder1.Length);
            }
        }
    }
}
