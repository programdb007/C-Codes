﻿using System;
using System.Linq;
using System.Text;

namespace ManipulatingText
{
    class Program
    {
        // Example 10-62. Simulating messy input
        private static string[] SoliloquizeLikeAUser()
        {
            return new string[] {
                "",
                null,
                " ",
                String.Empty,
                " To be, or not to be--that is the question: ",
                "Whether 'tis nobelr in the mind to suffer,",
                "\tThe slings and arrows of outrageous fortune ,",
                "",
                "\tOr to take arms against a sea of troubles, ",
                "And by opposing end them.",
                "",
                "",
                "",
                "",
                ""};
        }

        static void Main(string[] args)
        {
            {
                // Example 10-63. Cleaning up input
                string[] strings = SoliloquizeLikeAUser();
                string output = String.Empty; // This is equivalent to ""
                foreach (string line in strings)
                {
                    // Do something to look at the line...
                    // then...
                    output = output + line + Environment.NewLine;
                }
                Console.WriteLine(output);
            }

            Console.WriteLine("-------");

            {
                // Example 10-64. Building up strings with StringBuilder
                // and also
                // Example 10-73. Code from earlier for tidying up the text
                string[] strings = SoliloquizeLikeAUser();
                StringBuilder output = new StringBuilder();
                foreach (string line in strings)
                {
                    // Example 10-75. Detecting empty strings
                    //if (line != String.Empty)
                    // Example 10-76. Testing for either blank or null
                    if (!String.IsNullOrEmpty(line))
                    {
                        output.AppendLine(line);
                    }
                    else
                    {
                        System.Diagnostics.Debug.WriteLine("Found a blank line");
                    }
                }

                // Example 10-74. Fixing a specific typo
                output.Replace("nobelr", "nobler");
                Console.WriteLine(output.ToString());
            }

            Console.WriteLine("-------");

            {
                {
                    string[] strings = SoliloquizeLikeAUser();
                    StringBuilder output = new StringBuilder();
                    // Example 10-77. Trimming whitespace
                    foreach (string line in strings)
                    {
                        if (line != null)
                        {
                            //string trimmedLine = line.Trim();
                            // Example 10-78. Trimming specific characters
                            string trimmedLine = line.Trim(' ', '\t', ',');
                            if (trimmedLine.Length != 0)
                            {
                                output.AppendLine(trimmedLine);
                            }
                            else
                            {
                                System.Diagnostics.Debug.WriteLine(
                                "Found a blank line (after trimming)");
                            }
                        }
                        else
                        {
                            System.Diagnostics.Debug.WriteLine("Found a null line");
                        }
                    }

                    output.Replace("nobelr", "nobler");
                    Console.WriteLine(output.ToString());
                }
            }
        }

        // Example 10-79. Trimming any whitespace and specific additional characters
        private static string TrimWhitespaceAnd(
            string inputString,
            params char[] characters)
        {
            int start = 0;
            while (start < inputString.Length)
            {
                // If it is neither whitespace nor a character from our list
                // then we've hit the first non-trimmable character, so we can stop
                if (!char.IsWhiteSpace(inputString[start]) &&
                !characters.Contains(inputString[start]))
                {
                    break;
                }
                // Work forward a character
                start++;
            }
            // Work backwards from the end
            int end = inputString.Length - 1;
            while (end >= start)
            {
                // If it is neither whitespace nor a character from our list
                // then we've hit the first non-trimmable character
                if (!char.IsWhiteSpace(inputString[end]) &&
                !characters.Contains(inputString[end]))
                {
                    break;
                }
                // Work back a character
                end--;
            }
            // Work out how long our string is for the
            // substring function
            int length = (end - start) + 1;
            if (length == inputString.Length)
            {
                // If we didn't trim anything, just return the
                // input string (don't create a new one
                return inputString;
            }
            // If the length is zero, then return the empty string
            if (length == 0)
            {
                return string.Empty;
            }
            return inputString.Substring(start, length);
        }
    }
}
