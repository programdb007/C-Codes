﻿using System;

namespace Composing
{
    class Program
    {
        static void Fragments()
        {
            // Example 10-55. Concatenating strings
            string fragment1 = "To be, ";
            string fragment2 = "or not to be.";
            string composedString = fragment1 + fragment2;
            Console.WriteLine(composedString);

            // Example 10-56. Calling String.Concat explicitly
            string composedString2 = string.Concat(fragment1, fragment2);
            Console.WriteLine(composedString2);
        }

        // Example 10-57. Concatenating an array of strings
        static void Main(string[] args)
        {
            string[] strings = Soliloquize();
            // Modify this to false to switch to 10-58 version.
#if true
            string output = String.Concat(strings);
#else
            // Example 10-58. String.Join
            string output = String.Join(Environment.NewLine, strings);
#endif
            Console.WriteLine(output);
            Console.ReadKey();
        }
        private static string[] Soliloquize()
        {
            return new string[] {
                "To be, or not to be--that is the question:",
                "Whether 'tis nobler in the mind to suffer",
                "The slings and arrows of outrageous fortune",
                "Or to take arms against a sea of troubles",
                "And by opposing end them." };
        }
    }
}
