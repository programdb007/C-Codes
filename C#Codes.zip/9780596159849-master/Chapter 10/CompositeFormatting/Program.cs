﻿using System;

namespace CompositeFormatting
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 10-44. Basic use of String.Format
            int val1 = 32;
            double val2 = 123.457;
            DateTime val3 = new DateTime(1999, 11, 1, 17, 22, 25);
            string formattedString = String.Format("Val1: {0}, Val2: {1}, Val3: {2}",
            val1, val2, val3);
            Console.WriteLine(formattedString);

            // Example 10-45. Using format strings from String.Format
            int first = 32;
            double second = 123.457;
            DateTime third = new DateTime(1999, 11, 1, 17, 22, 25);
            string output = String.Format(
            "Date: {2:d}, Time: {2:t}, Val1: {0}, Val2: {1:#.##}",
            first, second, third);
            Console.WriteLine(output);
        }
    }
}
