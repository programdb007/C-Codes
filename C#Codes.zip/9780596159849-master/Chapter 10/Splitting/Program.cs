﻿using System;

namespace Splitting
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                // Example 10-59. Splitting a string
                string[] strings = Soliloquize();
                string output = String.Join(Environment.NewLine, strings);
                string[] splitStrings = output.Split(
                    new char[] { ' ', '\t', '\r', '\n', ',', '-', ':' });
                bool first = true;
                foreach (string splitBit in splitStrings)
                {
                    if (first)
                    {
                        first = false;
                    }
                    else
                    {
                        Console.Write(", ");
                    }
                    Console.Write(splitBit);
                }
            }

            Console.WriteLine();

            {
                string[] strings = Soliloquize();
                string output = String.Join(Environment.NewLine, strings);

                // Example 10-60. Eliminating empty strings in String.Split
                string[] splitStrings = output.Split(
                    new char[] { ' ', '\t', '\r', '\n', ',', '-', ':' },
                    StringSplitOptions.RemoveEmptyEntries);

                bool first = true;
                foreach (string splitBit in splitStrings)
                {
                    if (first)
                    {
                        first = false;
                    }
                    else
                    {
                        Console.Write(", ");
                    }
                    // Example 10-61. Forcing strings to lowercase
                    Console.Write(splitBit.ToLower());
                }
            }
        }

        private static string[] Soliloquize()
        {
            return new string[] {
                "To be, or not to be--that is the question:",
                "Whether 'tis nobler in the mind to suffer",
                "The slings and arrows of outrageous fortune",
                "Or to take arms against a sea of troubles",
                "And by opposing end them." };
        }

    }
}
