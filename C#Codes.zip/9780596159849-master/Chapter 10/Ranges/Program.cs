﻿using System;

namespace Ranges
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                // Example 10-52. Using Substring
                string myString = "This is the silliest stuff that ere I heard.";
                string subString = myString.Substring(5);
                string anotherSubString = myString.Substring(12, 8);
                Console.WriteLine(subString);
                Console.WriteLine(anotherSubString);
            }

            {
                // Example 10-54. Using our Right method
                string myString = "This is the silliest stuff that ere I heard.";
                string subString = Right(myString, 6);
                Console.WriteLine(subString);
            }
        }

        // Example 10-53. Getting characters from the righthand end of a string
        static string Right(string s, int length)
        {
            int startIndex = s.Length - length;
            return s.Substring(startIndex);
        }
    }
}
