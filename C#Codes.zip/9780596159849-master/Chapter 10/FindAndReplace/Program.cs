﻿using System;

namespace FindAndReplace
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 10-71. Searching for text
            string inputString =
            "If a dog and a man go into a bar, " +
            "is it necessarily the beginning of a joke?";
            int index = -1;
            do
            {
                index += 1;
                index = inputString.IndexOf(" a ", index);
                Console.WriteLine(index);
            }
            while (index >= 0);

            // Example 10-72. Replacing text
            string original = "Original text.";
            string replaced = original.Replace("Original", "Replaced");
            Console.WriteLine(original);
            Console.WriteLine(replaced);
        }
    }
}
