﻿using System;
using System.Text;

namespace Utf16Example1
{
    class Program
    {
        // Example 10-83. Using UTF-16 encoding
        static void Main(string[] args)
        {
            string listenUpFR = "Écoute-moi!";
            byte[] utf16Bytes = Encoding.Unicode.GetBytes(listenUpFR);
            Console.WriteLine("UTF-16");
            Console.WriteLine("-----");
            foreach (var encodedByte in utf16Bytes)
            {
                Console.Write(encodedByte);
                Console.Write(" ");
            }
            Console.ReadKey();
        }
    }
}
