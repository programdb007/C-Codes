﻿using System.Collections.Generic;

namespace Immutability
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 10-51. Using strings as keys in a dictionary
            // NOTE: this does NOT compile, for reasons described in the book.
            string myKey = "TheUniqueKey";
            Dictionary<string, object> myDictionary = new Dictionary<string, object>();
            myDictionary.Add(myKey, new object());
            // Imagine you could do this...
            myKey[2] = 'o';
        }
    }
}
