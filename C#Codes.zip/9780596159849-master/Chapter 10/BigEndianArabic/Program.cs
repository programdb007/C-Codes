﻿using System;
using System.Text;

namespace BigEndianArabic
{
    class Program
    {
        // Example 10-86. Big-endian Arabic
        static void Main(string[] args)
        {
            string listenUpArabic = "أنصت إليّ";
            byte[] utf16Bytes = Encoding.BigEndianUnicode.GetBytes(listenUpArabic);
            Console.WriteLine("UTF-16");
            Console.WriteLine("-----");
            foreach (var encodedByte in utf16Bytes)
            {
                Console.Write(string.Format("{0:X2}", encodedByte));
                Console.Write(" ");
            }
            Console.ReadKey();
        }
    }
}
