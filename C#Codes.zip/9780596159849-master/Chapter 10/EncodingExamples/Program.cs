﻿using System;
using System.Text;

namespace EncodingExamples
{
    class Program
    {
        // Example 10-80. Encoding text
        static void Main(string[] args)
        {
            string listenUp = "Listen up!";
            byte[] utf8Bytes = Encoding.UTF8.GetBytes(listenUp);
            byte[] asciiBytes = Encoding.ASCII.GetBytes(listenUp);
            Console.WriteLine("UTF-8");
            Console.WriteLine("-----");
            foreach (var encodedByte in utf8Bytes)
            {
                Console.Write(encodedByte);
                Console.Write(" ");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("ASCII");
            Console.WriteLine("-----");
            foreach (var encodedByte in asciiBytes)
            {
                Console.Write(encodedByte);
                Console.Write(" ");
            }
            Console.ReadKey();

            NonAscii();
        }

        private static void NonAscii()
        {
            // Example 10-81. Using a non-ASCII character
            string listenUp = "Écoute-moi!";
            byte[] utf8Bytes = Encoding.UTF8.GetBytes(listenUp);
            byte[] asciiBytes = Encoding.ASCII.GetBytes(listenUp);
            Console.WriteLine("UTF-8");
            Console.WriteLine("-----");
            foreach (var encodedByte in utf8Bytes)
            {
                Console.Write(encodedByte);
                Console.Write(" ");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("ASCII");
            Console.WriteLine("-----");
            foreach (var encodedByte in asciiBytes)
            {
                Console.Write(encodedByte);
                Console.Write(" ");
            }

            // Example 10-82. Decoding text
            string decodedUtf8 = Encoding.UTF8.GetString(utf8Bytes);
            string decodedAscii = Encoding.ASCII.GetString(asciiBytes);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Decoded UTF-8");
            Console.WriteLine("-------------");
            Console.WriteLine(decodedUtf8);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Decoded ASCII");
            Console.WriteLine("-------------");
            Console.WriteLine(decodedAscii);

            Console.ReadKey();
        }
    }
}
