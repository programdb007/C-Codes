﻿using System;

namespace StringIndexing
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 10-49. Retrieving characters with a string’s indexer
            string myString = "Indexing";
            char theThirdCharacter = myString[2];
            Console.WriteLine(theThirdCharacter);

            // Set this to true to see the compiler error as described in the book.
#if false
            // Example 10-50. Trying to assign a value with a string’s indexer
            string myString = "Indexing";
            myString[2] = 'f'; // Will fail to compile
#endif
        }
    }
}
