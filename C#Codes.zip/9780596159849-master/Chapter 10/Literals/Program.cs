﻿using System;

namespace Literals
{
    class Program
    {
        static void Main(string[] args)
        {
            // Note: these extra braces introduce scopes - this lets us
            // put multiple examples that use a variable called "myString"
            // in the same method, because variables are local to their
            // containing scope.

            {
                // Example 10-2. A string literal
                string myString = "Literal string";
                Console.WriteLine(myString);
            }

            {
                // Example 10-3. Initializing a string from char literals
                string myString = new string(new[] { 'H', 'e', 'l', 'l', 'o', ' ', '"', 'w', 'o', 'r', 'l', 'd', '"' });
                Console.WriteLine(myString);
            }

            // Example 10-4. Avoiding backslashes with @-quoting
            string multiLineString =
            @"Lots of
lines and
        tabs!";
            Console.WriteLine(multiLineString);
        }

    }
}
