﻿using System;
using System.Linq;
using System.Reflection;

namespace UsingASpecificType
{
    public class Tester
    {
        public static void Main()
        {
            // examine a single type
            Assembly a = Assembly.Load("Mscorlib");

            var matchingTypes = from t in a.GetTypes()
                                where typeof(MemberInfo).IsAssignableFrom(t)
                                select t;

            foreach (Type t in matchingTypes)
            {
                Console.WriteLine(t);
            }
        }
    }
}