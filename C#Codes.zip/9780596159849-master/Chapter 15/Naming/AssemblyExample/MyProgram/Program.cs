﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyLibrary;

namespace MyProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 15-10. Getting a type’s containing assembly’s name
            Console.WriteLine(typeof(MyType).Assembly.FullName);
        }
    }
}
