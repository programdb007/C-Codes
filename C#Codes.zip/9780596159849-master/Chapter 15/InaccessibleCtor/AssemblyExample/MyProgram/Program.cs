﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyLibrary;

namespace MyProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 15-6. Using the type and using its members
            MyType o;           // Compiles OK
            o = new MyType();   // Error
        }
    }
}
