﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyLibrary;

namespace MyProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 15-8. Using a type with an internal constructor from outside
            MyType o = Class1.MakeMeAnInstance();
        }
    }
}
