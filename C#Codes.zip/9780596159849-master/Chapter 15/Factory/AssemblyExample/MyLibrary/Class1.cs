﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyLibrary
{
    // Example 15-7. Factory method for a public type with an internal constructor
    public class Class1
    {
        public static MyType MakeMeAnInstance()
        {
            return new MyType();
        }
    }
}
