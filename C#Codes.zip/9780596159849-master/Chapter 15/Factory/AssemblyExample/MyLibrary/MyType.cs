﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyLibrary
{
    // Example 15-5. Public type, internal constructor
    public class MyType
    {
        internal MyType() { }
    }
}
