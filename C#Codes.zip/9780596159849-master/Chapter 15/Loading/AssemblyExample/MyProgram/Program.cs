﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MyLibrary;

namespace MyProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            new Program().Foo();
        }

        // Example 15-12. A rare occurrence
        public void Foo()
        {
            if (DateTime.Now.Year == 1973)
            {
                SomeExternalType.Disco();
            }
        }
    }
}
