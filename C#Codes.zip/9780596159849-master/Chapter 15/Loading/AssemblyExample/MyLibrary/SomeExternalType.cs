﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyLibrary
{
    public class SomeExternalType
    {
        public static void Disco()
        {
            Console.WriteLine("Oh yeah!");
        }
    }
}
