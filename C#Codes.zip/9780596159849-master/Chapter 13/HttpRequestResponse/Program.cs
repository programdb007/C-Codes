﻿using System;
using System.IO;
using System.Net;
using System.Net.Cache;
namespace HttpRequestResponse
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                // Example 13-13. Fetching a string with HttpWebRequest and HttpWebResponse
                HttpWebRequest req = (HttpWebRequest) WebRequest.Create("http://oreilly.com/");
                using (HttpWebResponse resp = (HttpWebResponse) req.GetResponse())
                using (Stream respStream = resp.GetResponseStream())
                using (StreamReader reader = new StreamReader(respStream))
                {
                    string pageContent = reader.ReadToEnd();
                    Console.WriteLine(pageContent);
                }
            }

            {
                // Example 13-14. Changing the user agent header with HttpWebRequest
                HttpWebRequest req = (HttpWebRequest) WebRequest.Create("http://oreilly.com/");
                req.UserAgent = "Mozilla/5.0 (iPod; U; CPU iPhone OS 2_2_1 like Mac OS X; en-us) AppleWebKit/525.18.1 (KHTML, like Gecko) Mobile/5H11a";
                using (HttpWebResponse resp = (HttpWebResponse) req.GetResponse())
                using (Stream respStream = resp.GetResponseStream())
                using (StreamReader reader = new StreamReader(respStream))
                {
                    string pageContent = reader.ReadToEnd();
                    Console.WriteLine(pageContent);
                }
            }

            {
                // Example 13-15. Obtaining a response asynchronously
                HttpWebRequest req = (HttpWebRequest) WebRequest.Create("http://oreilly.com/");
                req.BeginGetResponse(delegate(IAsyncResult asyncResult)
                {
                    using (HttpWebResponse resp = (HttpWebResponse)
                    req.EndGetResponse(asyncResult))
                    using (Stream respStream = resp.GetResponseStream())
                    using (StreamReader reader = new StreamReader(respStream))
                    {
                        string pageContent = reader.ReadToEnd();
                        Console.WriteLine(pageContent);
                    }
                }, null);

                Console.ReadKey();
            }
        }

        static void Credentials()
        {
            {
                // Example 13-16. Enabling the use of integrated authentication
                HttpWebRequest request =
                    (HttpWebRequest) WebRequest.Create("http://intraweb/");
                request.Credentials = CredentialCache.DefaultCredentials;
            }

            {
                // Example 13-17. Providing credentials for basic or digest authentication
                HttpWebRequest request =
                    (HttpWebRequest) WebRequest.Create("https://intraweb/");
                request.Credentials = new NetworkCredential("user1", "p@ssw0rd");
            }
        }

        static void Proxy()
        {
            // Example 13-19. Setting an explicit proxy
            HttpWebRequest request =
            (HttpWebRequest) WebRequest.Create("https://intraweb/");
            request.Proxy = new WebProxy("http://corpwebproxy/");
        }

        static void Cache()
        {
            // Example 13-20. Setting cache policy
            HttpRequestCachePolicy cachePolicy = new HttpRequestCachePolicy(
            HttpRequestCacheLevel.CacheIfAvailable);
            HttpWebRequest request =
            (HttpWebRequest) WebRequest.Create("https://intraweb/");
            request.CachePolicy = cachePolicy;
        }

        static void Cookies()
        {
            // Example 13-21. Getting the cookies from a response
            CookieContainer container = new CookieContainer();

            Uri address = new Uri("http://amazon.com/");
            HttpWebRequest req = (HttpWebRequest) WebRequest.Create(address);
            HttpWebResponse resp = (HttpWebResponse) req.GetResponse();

            CookieCollection cookies = resp.Cookies;
            container.Add(address, cookies);
        }
    }
}
