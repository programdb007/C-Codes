﻿using System;
using System.Net;

namespace WebClientExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 13-11. Fetching content with WebClient
            WebClient client = new WebClient();
            string pageContent = client.DownloadString("http://oreilly.com/");

            Console.WriteLine(pageContent);


            byte[] data =
                client.DownloadData("http://oreilly.com/images/oreilly/oreilly_large.gif");

            client.DownloadFile("http://oreilly.com/", @"c:\temp\oreilly.html");
        }
    }
}
