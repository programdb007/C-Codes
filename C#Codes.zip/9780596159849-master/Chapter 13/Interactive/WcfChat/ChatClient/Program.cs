﻿using System;
using ChatClient.ChatService;

namespace ChatClient
{
    class Program
    {
        // Example 13-7. Client with input loop
        static void Main(string[] args)
        {
            ChatServiceClient chatProxy = new ChatServiceClient();

            Console.WriteLine("Please enter your name:");
            string name = Console.ReadLine();
            while (true)
            {
                Console.WriteLine("Type a note (or hit enter to quit):");
                string note = Console.ReadLine();
                if (string.IsNullOrEmpty(note))
                {
                    break;
                }
                chatProxy.PostNote(name, note);
            }
        }
    }
}
