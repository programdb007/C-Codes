﻿using System;

namespace ChatServerLibrary
{
    public class ChatService : IChatService
    {
        public void PostNote(string from, string note)
        {
            Console.WriteLine("{0}: {1}", from, note);
        }
    }
}
