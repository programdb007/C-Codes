﻿using System.ServiceModel;

namespace ChatServerLibrary
{
    [ServiceContract]
    public interface IChatService
    {
        [OperationContract]
        void PostNote(string from, string note);
    }
}
