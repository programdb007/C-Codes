﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace SocketServer
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 13-27. The complete daytime service
            // Example 13-25. Listening for incoming TCP connections
            using (Socket daytimeListener = new Socket(
                AddressFamily.InterNetworkV6,
                SocketType.Stream,
                ProtocolType.Tcp))
            {
                daytimeListener.SetSocketOption(
                    SocketOptionLevel.IPv6, (SocketOptionName) 27, 0);

                IPEndPoint daytimeEndpoint = new IPEndPoint(IPAddress.IPv6Any, 13);
                daytimeListener.Bind(daytimeEndpoint);
                daytimeListener.Listen(20);

                // Example 13-26. Accepting incoming connections
                while (true)
                {
                    Socket incomingConnection = daytimeListener.Accept();
                    using (NetworkStream connectionStream =
                                        new NetworkStream(incomingConnection, true))
                    using (StreamWriter writer = new StreamWriter(connectionStream))
                    {
                        writer.WriteLine(DateTime.Now);
                    }
                }
            }
        }
    }
}