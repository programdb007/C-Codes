﻿using System.ServiceModel;

namespace ChatServerLibrary
{
    // Example 13-1. A service contract
    [ServiceContract]
    public interface IChatService
    {
        [OperationContract]
        void DoWork();
    }
}
