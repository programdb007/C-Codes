﻿using System;
using System.ServiceModel;
using ChatClient.ChatService;

namespace ChatClient
{
    // Example 13-10. Implementing the client-side callback interface
    [CallbackBehavior(ConcurrencyMode = ConcurrencyMode.Reentrant)]
    class ChatCallback : IChatServiceCallback
    {
        public void NotePosted(string from, string note)
        {
            Console.WriteLine("{0}: {1}", from, note);
        }
    }
}
