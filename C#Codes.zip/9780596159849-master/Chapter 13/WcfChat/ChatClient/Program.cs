﻿using System;
using ChatClient.ChatService;
using System.ServiceModel;

namespace ChatClient
{
    class Program
    {
        static void Main(string[] args)
        {
            ChatCallback callbackObject = new ChatCallback();
            InstanceContext clientContext = new InstanceContext(callbackObject);
            ChatServiceClient chatProxy = new ChatServiceClient(clientContext);

            Console.WriteLine("Please enter your name:");
            bool ok = false;
            while (!ok)
            {
                string name = Console.ReadLine();
                ok = chatProxy.Connect(name);
                if (!ok)
                {
                    Console.WriteLine("That name is taken. Please try another.");
                }
            }
            while (true)
            {
                Console.WriteLine("Type a note (or hit enter to quit):");
                string note = Console.ReadLine();
                if (string.IsNullOrEmpty(note))
                {
                    break;
                }
                chatProxy.PostNote(note);
            }
            chatProxy.Disconnect();
        }
    }
}
