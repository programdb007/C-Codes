﻿using System.ServiceModel;

namespace ChatServerLibrary
{
    // Example 13-8. Callback interface for duplex contract
    public interface IChatClient
    {
        [OperationContract]
        void NotePosted(string from, string note);
    }
}
