﻿using System.ServiceModel;

namespace ChatServerLibrary
{
    // Example 13-9. Duplex contract
    [ServiceContract(
        CallbackContract = typeof(IChatClient),
        SessionMode = SessionMode.Required)]
    public interface IChatService
    {
        [OperationContract]
        bool Connect(string name);

        [OperationContract]
        void PostNote(string note);

        [OperationContract]
        void Disconnect();
    }
}
