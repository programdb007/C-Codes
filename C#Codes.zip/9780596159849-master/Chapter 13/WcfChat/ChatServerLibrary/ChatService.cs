﻿using System;
using System.Linq;
using System.ServiceModel;
using System.Collections.Generic;

namespace ChatServerLibrary
{
    [ServiceBehavior(
        InstanceContextMode = InstanceContextMode.Single,
        ConcurrencyMode = ConcurrencyMode.Reentrant)]
    public class ChatService : IChatService
    {
        private Dictionary<IChatClient, string> clientsAndNames =
            new Dictionary<IChatClient, string>();

        public bool Connect(string name)
        {
            if (clientsAndNames.ContainsValue(name))
            {
                // Name already in use, so refuse connection
                return false;
            }

            IChatClient clientCallback =
                OperationContext.Current.GetCallbackChannel<IChatClient>();

            // clientsAndNames is shared state, but we're not locking
            // here, because we're relying on ConcurrentMode.Reentrant
            // to give us messages one at a time.
            clientsAndNames.Add(clientCallback, name);
            Console.WriteLine(name + " connected");

            return true;
        }

        public void PostNote(string note)
        {
            IChatClient clientCallback =
                OperationContext.Current.GetCallbackChannel<IChatClient>();
            string name = clientsAndNames[clientCallback];

            Console.WriteLine("{0}: {1}", name, note);

            // ToArray() makes copy of the collection. This avoids an
            // exception due to the collection being modified if we have
            // to disconnect a client part way through the loop.
            KeyValuePair<IChatClient, string>[] copiedNames =
                clientsAndNames.ToArray();
            foreach (KeyValuePair<IChatClient, string> client in copiedNames)
            {
                // Avoid sending the message back to the client that just sent
                // it - they already know what they just typed.
                if (client.Key != clientCallback)
                {
                    Console.WriteLine("Sending note to {0}", client.Value);
                    try
                    {
                        client.Key.NotePosted(name, note);
                    }
                    catch (Exception x)
                    {
                        Console.WriteLine("Error: {0}", x);
                        DisconnectClient(client.Key);
                    }
                }
            }
        }

        public void Disconnect()
        {
            IChatClient clientCallback =
                OperationContext.Current.GetCallbackChannel<IChatClient>();
            DisconnectClient(clientCallback);
        }

        private void DisconnectClient(IChatClient clientCallback)
        {
            string name = clientsAndNames[clientCallback];
            Console.WriteLine(name + " disconnected");
            clientsAndNames.Remove(clientCallback);
        }
    }
}
