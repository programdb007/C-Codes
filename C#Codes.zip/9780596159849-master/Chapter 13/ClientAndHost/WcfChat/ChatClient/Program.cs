﻿using ChatClient.ChatService;

namespace ChatClient
{
    class Program
    {
        // Example 13-5. Invoking a web service with a WCF proxy
        static void Main(string[] args)
        {
            using (ChatServiceClient chatProxy = new ChatServiceClient())
            {
                chatProxy.PostNote("Ian", "Hello again, world");
            }
        }
    }
}
