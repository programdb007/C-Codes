﻿using System;
using System.ServiceModel;
using ChatServerLibrary;

namespace ChatHost
{
    class Program
    {
        // Example 13-4. Hosting a WCF service
        static void Main(string[] args)
        {
            using (ServiceHost host = new ServiceHost(typeof(ChatService)))
            {
                host.Open();
                Console.WriteLine("Service ready");
                Console.ReadKey();
            }
        }
    }
}
