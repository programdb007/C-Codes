﻿using System.ServiceModel;

namespace ChatServerLibrary
{
    [ServiceContract]
    public interface IChatService
    {
        // Example 13-2. Modifying the contract
        [OperationContract]
        void PostNote(string from, string note);
    }
}
