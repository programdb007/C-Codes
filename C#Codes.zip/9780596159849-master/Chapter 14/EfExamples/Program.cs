﻿using System;
using System.Configuration;
using System.Data.EntityClient;
using System.Data.Objects;
using System.Linq;
using System.Transactions;

namespace EfExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 14-3. Using generated entity types
            using (var dbContext = new AdventureWorksLT2008Entities())
            {
                DateTime orderDate = new DateTime(2004, 6, 1);
                var orders = from order in dbContext.SalesOrderHeaders
                             where order.OrderDate == orderDate
                             select order;
                foreach (SalesOrderHeader order in orders)
                {
                    Console.WriteLine(order.TotalDue);
                }
            }

            // Example 14-4. Using a navigation property
            using (var dbContext = new AdventureWorksLT2008Entities())
            {
                var customerOrderCounts = from cust in dbContext.Customers
                                          select new
                                          {
                                              cust.CustomerID,
                                              OrderCount = cust.SalesOrderHeaders.Count
                                          };
                foreach (var customerInfo in customerOrderCounts)
                {
                    Console.WriteLine("Customer {0} has {1} orders",
                    customerInfo.CustomerID, customerInfo.OrderCount);
                }
            }

            using (var dbContext = new AdventureWorksLT2008Entities())
            {
                // Example 14-5. Traversing multiple relationships with navigation properties
                var info = from cust in dbContext.Customers
                           select new
                           {
                               cust.CustomerID,
                               Orders = from order in cust.SalesOrderHeaders
                                        where order.Status == 5
                                        select new
                                        {
                                            order.TotalDue,
                                            ItemCount = order.SalesOrderDetails.Count
                                        }
                           };

                foreach (var item in info)
                {
                    if (item.Orders.Count() > 0)
                    {
                        Console.WriteLine(item.CustomerID);
                        foreach (var order in item.Orders)
                        {
                            Console.WriteLine(" " + order);
                        }
                    }
                }

                {
                    // Example 14-6. Following an association after the initial query
                    Customer myCustomer = dbContext.Customers.Single(
                        cust => cust.CustomerID == 29531);
                    Console.WriteLine(myCustomer.SalesOrderHeaders.Count);
                }

                {
                    // Example 14-7. Explicitly loading entities for an association
                    Customer myCustomer = dbContext.Customers.Single(
                    cust => cust.CustomerID == 29531);
                    myCustomer.SalesOrderHeaders.Load();
                    Console.WriteLine(myCustomer.SalesOrderHeaders.Count);
                }

                {
                    // Example 14-8. Specifying relationships to preload
                    var customersWithOrderDetails = dbContext.Customers.
                        Include("SalesOrderHeaders.SalesOrderDetails");
                    Customer myCustomer = customersWithOrderDetails.Single(
                        cust => cust.CustomerID == 29531);
                    Console.WriteLine(myCustomer.SalesOrderHeaders.Count);
                }


                {
                    DateTime orderDate = new DateTime(2004, 6, 1);

                    // Example 14-9. Simple LINQ to Entities query expression
                    var orders = from order in dbContext.SalesOrderHeaders
                                 where order.OrderDate == orderDate
                                 select order;

                    // Query not actually executed at this point. Would need
                    // to start attempting to retrieve items from the query
                    // before any real work is done.

                    // Even this next example doesn't execute the 'orders'
                    // query even though it refers to it - it builds a new
                    // query that is an extended version of the original.

                    // Example 14-10. Chained query
                    var orderedOrders = from order in orders
                                        orderby order.OrderDate
                                        select order;
                }

                {
                    DateTime orderDate = new DateTime(2004, 6, 1);

                    // Example 14-11. That same query, written out in full
                    var orderedOrders = from order in dbContext.SalesOrderHeaders
                                        where order.OrderDate == orderDate
                                        orderby order.OrderDate
                                        select order;
                }
            }

            // Example 14-12. Querying with ESQL
            using (var dbContext = new AdventureWorksLT2008Entities())
            {
                DateTime orderDate = new DateTime(2004, 6, 1);
                var query = dbContext.CreateQuery<SalesOrderHeader>("SELECT VALUE o " +
                        "FROM AdventureWorksLT2008Entities.SalesOrderHeaders AS o " +
                        "WHERE o.OrderDate = @orderDate",
                    new ObjectParameter("orderDate", orderDate));

                foreach (var order in query)
                {
                    Console.WriteLine(order.TotalDue);
                }
            }

            // Example 14-14. Passing an explicit connection string

            // Retrieve the connection string for the underlying database provider.
            ConnectionStringSettings dbConnectionInfo =
                ConfigurationManager.ConnectionStrings["AdventureWorksSql"];

            var csb = new EntityConnectionStringBuilder();
            csb.Provider = dbConnectionInfo.ProviderName;
            csb.ProviderConnectionString = dbConnectionInfo.ConnectionString;
            csb.Metadata = "res://*/AdventureWorksModel.csdl|" +
                "res://*/AdventureWorksModel.ssdl|res://*/AdventureWorksModel.msl";

            using (var dbContext = new AdventureWorksLT2008Entities(csb.ConnectionString))
            {
                foreach (SalesOrderHeader order in dbContext.SalesOrderHeaders)
                {
                    Console.WriteLine(order.TotalDue);
                }
            }


            // Example 14-16. Modifying an existing entity
            using (var dbContext = new AdventureWorksLT2008Entities())
            {
                var orderQuery = from customer in dbContext.Customers
                                 where customer.CustomerID == 29531
                                 from order in customer.SalesOrderHeaders
                                 orderby order.OrderDate descending
                                 select order;
                SalesOrderHeader latestOrder = orderQuery.First();
                latestOrder.Comment = "Call customer when goods ready to ship";
                dbContext.SaveChanges();
            }

            try
            {
                using (var dbContext = new AdventureWorksLT2008Entities())
                {
                    // Example 14-17. Failing to meet constraints on a new entity
                    SalesOrderDetail detail = new SalesOrderDetail();
                    dbContext.AddToSalesOrderDetails(detail);
                    // Will throw an exception!
                    dbContext.SaveChanges();
                }
            }
            catch (Exception x)
            {
                Console.WriteLine(x);
            }

            using (var dbContext = new AdventureWorksLT2008Entities())
            {
                var orderQuery = from customer in dbContext.Customers
                                 where customer.CustomerID == 29531
                                 from order in customer.SalesOrderHeaders
                                 orderby order.OrderDate descending
                                 select order;
                SalesOrderHeader latestOrder = orderQuery.First();


                // Example 14-18. Adding a new entity
                // ...where latestOrder is a SalesOrderHeader fetched with code like
                // that in Example 14-16.
                SalesOrderDetail detail = new SalesOrderDetail();
                detail.SalesOrderHeader = latestOrder;
                detail.ModifiedDate = DateTime.Now;
                detail.OrderQty = 1;
                detail.ProductID = 680; // HL Road Frame - Black, 58
                dbContext.AddToSalesOrderDetails(detail);
                dbContext.SaveChanges();

                // Example 14-19. Deleting an entity
                dbContext.DeleteObject(detail);
                dbContext.SaveChanges();
            }

            // Example 14-20. TransactionScope
            using (var dbContext = new AdventureWorksLT2008Entities())
            {
                using (var txScope = new TransactionScope())
                {
                    var customersWithOrders = from cust in dbContext.Customers
                                              where cust.SalesOrderHeaders.Count > 0
                                              select cust;
                    foreach (var customer in customersWithOrders)
                    {
                        Console.WriteLine("Customer {0} has {1} orders",
                        customer.CustomerID, customer.SalesOrderHeaders.Count);
                    }
                    txScope.Complete();
                }
            }
        }
    }
}
