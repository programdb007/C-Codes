﻿using System.Data.Services;

namespace WcfDsExamples
{
    public class MyData : DataService<AdventureWorksLT2008Entities>
    {
        // Example 14-21. Making entities available
        public static void InitializeService(IDataServiceConfiguration config)
        {
            config.SetEntitySetAccessRule("Customers",
                                          EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("SalesOrderHeaders",
                                          EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("SalesOrderDetails",
                                          EntitySetRights.AllRead);
        }
    }
}
