﻿using System;
using System.Linq;
using WcfDsClient.ServiceReference1;

namespace WcfDsClient
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 14-23. Client-side WCF Data Services code
            var ctx = new AdventureWorksLT2008Entities(
                new Uri("http://localhost:1181/MyData.svc"));
            var customers = from customer in ctx.Customers
                            where customer.FirstName == "Cory"
                            select customer;

            foreach (Customer customer in customers)
            {
                Console.WriteLine(customer.CompanyName);
            }
        }
    }
}
