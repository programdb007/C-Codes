﻿using System;
using System.Data.Common;
using System.Data.SqlClient;

namespace BasicAdoNet
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 14-1. Basic data access with ADO.NET
            string sqlConnectionString = @"Data Source=.\sqlexpress;" +
                "Initial Catalog=AdventureWorksLT2008;Integrated Security=True";
            string state = "California";
            using (DbConnection conn = new SqlConnection(sqlConnectionString))
            using (DbCommand cmd = conn.CreateCommand())
            {
                cmd.CommandText =
                    "SELECT AddressLine1, AddressLine2, City FROM SalesLT.Address WHERE " +
                    "StateProvince=@state";
                DbParameter stateParam = cmd.CreateParameter();
                stateParam.ParameterName = "@state";
                stateParam.Value = state;
                cmd.Parameters.Add(stateParam);

                conn.Open();
                using (DbDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string addressLine1 = reader.GetString(0);
                        // AddressLine2 is nullable, so we need to be prepared to get
                        // back either a string or a DBNull
                        string addressLine2 = reader.GetValue(1) as string;
                        string city = reader.GetString(2);

                        Console.WriteLine(addressLine1);
                        Console.WriteLine(addressLine2);
                        Console.WriteLine(city);
                    }
                }
            }
        }
    }
}
