﻿using System;
using System.IO;
using System.Reflection;

namespace HorribleOfficeInterop
{
    class Program
    {
        // Example 1-3. The horrors of Office interop before C# 4.0
        static void Main(string[] args)
        {
            var wordApp = new Microsoft.Office.Interop.Word.Application();
            object fileName = Path.Combine(
                // Slight change from book to deal with the fact that some
                // versions of Office will end up looking in c:\Windows\System32
                // by default.
                Directory.GetCurrentDirectory(),
                @"WordFile.docx");
            object missing = System.Reflection.Missing.Value;
            object readOnly = true;
            Microsoft.Office.Interop.Word._Document doc =
                wordApp.Documents.Open(ref fileName, ref missing, ref readOnly,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing);
            object docProperties = doc.BuiltInDocumentProperties;
            Type docPropType = docProperties.GetType();
            object authorProp = docPropType.InvokeMember("Item",
                BindingFlags.Default | BindingFlags.GetProperty,
                null, docProperties,
                new object[] { "Author" });
            Type propType = authorProp.GetType();
            string authorName = propType.InvokeMember("Value",
                BindingFlags.Default | BindingFlags.GetProperty,
                null, authorProp,
                new object[] { }).ToString();
            object saveChanges = false;
            doc.Close(ref saveChanges, ref missing, ref missing);
            Console.WriteLine(authorName);
        }
    }
}
