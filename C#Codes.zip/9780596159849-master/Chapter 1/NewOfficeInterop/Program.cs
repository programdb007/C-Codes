﻿using System;
using System.IO;

namespace NewOfficeInterop
{
    class Program
    {
        // Example 1-4. Office interop with C# 4.0
        static void Main(string[] args)
        {
            // Slight change from book to deal with the fact that some
            // versions of Office will end up looking in c:\Windows\System32
            // by default.
            string path = Path.Combine(
                Directory.GetCurrentDirectory(),
                @"WordFile.docx");

            var wordApp = new Microsoft.Office.Interop.Word.Application();
            Microsoft.Office.Interop.Word._Document doc =
                wordApp.Documents.Open(path, ReadOnly: true);
            dynamic docProperties = doc.BuiltInDocumentProperties;
            string authorName = docProperties["Author"].Value;
            doc.Close(SaveChanges: false);
            Console.WriteLine(authorName);
        }
    }
}
