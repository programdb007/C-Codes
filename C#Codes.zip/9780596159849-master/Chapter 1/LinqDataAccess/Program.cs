﻿using System;
using System.Linq;

namespace LinqDataAccess
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var pubs = new PubsEntities())
            {
                // Example 1-2. Data access with LINQ
                var californianAuthors = from author in pubs.authors
                                         where author.state == "CA"
                                         select new
                                         {
                                             author.au_fname,
                                             author.au_lname
                                         };
                foreach (var author in californianAuthors)
                {
                    Console.WriteLine(author);
                }
            }
        }
    }
}
