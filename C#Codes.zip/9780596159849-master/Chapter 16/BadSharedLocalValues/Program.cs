﻿using System;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        // Visible to all threads, thanks to use of
        // anonymous method. (Bad, in this example.)
        int i = 0;

        ParameterizedThreadStart go = delegate(object name)
        {
            // Modifying shared state without suitable protection - bad!
            for (; i < 100; ++i)
            {
                Console.WriteLine("{0}: {1}", name, i);
            }
        };

        Thread t1 = new Thread(go);
        Thread t2 = new Thread(go);

        t1.Start("One");
        t2.Start("Two");

        go("Main");
    }
}