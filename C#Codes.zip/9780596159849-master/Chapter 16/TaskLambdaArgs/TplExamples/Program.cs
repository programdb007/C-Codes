﻿using System;
using System.Threading.Tasks;

namespace TplExamples
{
    class Program
    {
        // Example 16-18. Passing more arguments with lambdas
        static void Main(string[] args)
        {
            Task.Factory.StartNew(() => Go("One", 100));
            Task.Factory.StartNew(() => Go("Two", 500));

            Console.ReadKey();
        }

        static void Go(string name, int iterations)
        {
            for (int i = 0; i < iterations; ++i)
            {
                Console.WriteLine("{0}: {1}", name, i);
            }
        }
    }
}