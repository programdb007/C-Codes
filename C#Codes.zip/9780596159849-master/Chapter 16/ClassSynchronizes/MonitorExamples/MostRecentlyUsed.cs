﻿using System.Collections.Generic;

namespace MonitorExamples
{
    // Example 16-13. Adding locking to a class
    class MostRecentlyUsed
    {
        private List<string> items = new List<string>();
        private int maxItems;
        private object lockObject = new object();

        public MostRecentlyUsed(int maximumItemCount)
        {
            maxItems = maximumItemCount;
        }

        public void UseItem(string item)
        {
            lock (lockObject)
            {
                // If the item was already in the list, and isn't the first item,
                // remove it from its current position, since we're about to make
                // it this first item.
                int itemIndex = items.IndexOf(item);
                if (itemIndex > 0)
                {
                    items.RemoveAt(itemIndex);
                }
                // If the item's already the first, we don't need to do anything.
                if (itemIndex != 0)
                {
                    items.Insert(0, item);
                    // Ensure we have no more than the maximum specified
                    // number of items.
                    if (items.Count > maxItems)
                    {
                        items.RemoveAt(items.Count - 1);
                    }
                }
            }
        }

        public IEnumerable<string> GetItems()
        {
            lock (lockObject)
            {
                return items.ToArray();
            }
        }
    }
}