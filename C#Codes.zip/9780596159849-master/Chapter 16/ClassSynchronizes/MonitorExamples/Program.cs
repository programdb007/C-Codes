﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace MonitorExamples
{
    class Program
    {
        const int Iterations = 10000;

        static void TestMru(MostRecentlyUsed mru)
        {
            Random r = new Random(Thread.CurrentThread.ManagedThreadId);
            string[] items = { "One", "Two", "Three", "Four", "Five",
                                 "Six", "Seven", "Eight" };
            for (int i = 0; i < Iterations; ++i)
            {
                mru.UseItem(items[r.Next(items.Length)]);
            }
        }

        static void Main(string[] args)
        {
            MostRecentlyUsed mru = new MostRecentlyUsed(4);

            const int TestThreadCount = 2;
            List<Thread> threads = (from i in Enumerable.Range(0, TestThreadCount)
                                    select new Thread(() => TestMru(mru))).ToList();

            threads.ForEach(t => t.Start());
            threads.ForEach(t => t.Join());

            foreach (string item in mru.GetItems())
            {
                Console.WriteLine(item);
            }
        }
    }
}
