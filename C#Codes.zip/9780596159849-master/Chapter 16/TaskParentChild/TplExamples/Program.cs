﻿using System;
using System.Threading.Tasks;

namespace TplExamples
{
    class Program
    {
        // Example 16-20. Task with children
        static void Main(string[] args)
        {
            Task t = Task.Factory.StartNew(() =>
            {
                Task.Factory.StartNew(() => Go("One", 100),
                                      TaskCreationOptions.AttachedToParent);
                Task.Factory.StartNew(() => Go("Two", 500),
                                      TaskCreationOptions.AttachedToParent);
            });

            t.Wait();
        }

        static void Go(string name, int iterations)
        {
            for (int i = 0; i < iterations; ++i)
            {
                Console.WriteLine("{0}: {1}", name, i);
            }
        }
    }
}