﻿using System;
using System.IO;
using System.Threading;
using System.Windows;

namespace Affinity
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Ensure there's something in the log file we read later in the example
            using (StreamWriter w = File.AppendText(@"c:\temp\log.txt"))
            {
                w.WriteLine("App started at " + DateTime.Now);
            }
        }

        private void runWorkAsyncButton_Click(object sender, RoutedEventArgs e)
        {
            // Example 16-7. Handling thread affinity with SynchronizationContext
            SynchronizationContext originalContext = SynchronizationContext.Current;

            ThreadPool.QueueUserWorkItem(delegate
            {
                string text = File.ReadAllText(@"c:\temp\log.txt");
                originalContext.Post(delegate
                {
                    myTextBox.Text = text;
                }, null);
            });
        }
    }
}
