﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace MonitorExamples
{
    class Program
    {
        // Example 16-10. Testing the MostRecentlyUsed class
        const int Iterations = 10000;

        static void TestMru(MostRecentlyUsed mru)
        {
            // Initializing random number generator with thread ID ensures
            // each thread provides different data. (Although it also makes
            // each test run different, which may not be ideal.)
            Random r = new Random(Thread.CurrentThread.ManagedThreadId);
            string[] items = { "One", "Two", "Three", "Four", "Five",
                                 "Six", "Seven", "Eight" };
            for (int i = 0; i < Iterations; ++i)
            {
                mru.UseItem(items[r.Next(items.Length)]);
            }
        }

        static void Main(string[] args)
        {
            // Example 16-11. Executing a multithreaded test
            MostRecentlyUsed mru = new MostRecentlyUsed(4);

            const int TestThreadCount = 2;
            List<Thread> threads = (from i in Enumerable.Range(0, TestThreadCount)
                                    select new Thread(() => TestMru(mru))).ToList();

            threads.ForEach(t => t.Start());
            threads.ForEach(t => t.Join());

            foreach (string item in mru.GetItems())
            {
                Console.WriteLine(item);
            }
        }
    }
}
