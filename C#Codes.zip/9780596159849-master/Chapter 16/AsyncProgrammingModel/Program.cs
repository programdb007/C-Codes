﻿using System;
using System.Net;

namespace AsyncProgrammingModel
{
    // Example 16-16. Using the Asynchronous Programming Model
    class Program
    {
        static void Main(string[] args)
        {
            Dns.BeginGetHostEntry("oreilly.com", OnGetHostEntryComplete, 42);
            Console.ReadKey();
        }

        static void OnGetHostEntryComplete(IAsyncResult iar)
        {
            IPHostEntry result = Dns.EndGetHostEntry(iar);
            Console.WriteLine(result.AddressList[0]);
            Console.WriteLine(iar.AsyncState);
        }
    }
}
