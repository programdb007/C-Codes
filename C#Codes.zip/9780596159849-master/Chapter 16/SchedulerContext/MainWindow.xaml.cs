﻿using System.Net;
using System.Threading.Tasks;
using System.Windows;

namespace SchedulerContext
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Example 16-21. Continuation on a UI thread
        void OnButtonClick(object sender, RoutedEventArgs e)
        {
            TaskScheduler uiScheduler =
                TaskScheduler.FromCurrentSynchronizationContext();
            Task<string>.Factory.StartNew(GetData)
                            .ContinueWith((task) => UpdateUi(task.Result),
                                          uiScheduler);
        }

        string GetData()
        {
            WebClient w = new WebClient();
            return w.DownloadString("http://oreilly.com/");
        }

        void UpdateUi(string info)
        {
            myTextBox.Text = info;
        }
    }
}
