﻿using System.Net;
using System.Threading.Tasks;
using System.Windows;

namespace SchedulerContext
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        void OnButtonClick(object sender, RoutedEventArgs e)
        {
            // Example 16-22. Creating a task from an APM implementation
            TaskScheduler uiScheduler = TaskScheduler.FromCurrentSynchronizationContext();
            Task<IPHostEntry>.Factory.FromAsync(
                                Dns.BeginGetHostEntry, Dns.EndGetHostEntry,
                                "oreilly.com", null)
                .ContinueWith((task) => UpdateUi(task.Result.AddressList[0].ToString()),
                              uiScheduler);
        }

        void UpdateUi(string info)
        {
            myTextBox.Text = info;
        }
    }
}
