﻿using System;
using System.Threading;

class Program
{
    // Visible to all threads. (Bad, in this example.)
    static int i;

    static void Main(string[] args)
    {
        i = 0;
        Thread t1 = new Thread(Go);
        Thread t2 = new Thread(Go);

        t1.Start("One");
        t2.Start("Two");

        Go("Main");
    }

    static void Go(object name)
    {
        // Modifying shared state without suitable protection - bad!
        for (; i < 100; ++i)
        {
            Console.WriteLine("{0}: {1}", name, i);
        }
    }
}