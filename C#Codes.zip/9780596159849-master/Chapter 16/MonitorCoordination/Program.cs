﻿using System;
using System.Threading;

namespace MonitorCoordination
{
    // Example 16-15. Using WaitForIt
    class Program
    {
        static void Main(string[] args)
        {
            WaitForIt waiter = new WaitForIt();

            ThreadStart twork = delegate
            {
                Console.WriteLine("Thread running...");
                Thread.Sleep(1000);
                Console.WriteLine("Notifying");
                waiter.GoNow();
                Console.WriteLine("Notified");
                Thread.Sleep(1000);
                Console.WriteLine("Thread exiting...");
            };

            Thread t = new Thread(twork);
            Console.WriteLine("Starting new thread");
            t.Start();
            Console.WriteLine("Waiting for thread to get going");
            waiter.WaitUntilReady();
            Console.WriteLine("Wait over");
        }
    }
}
