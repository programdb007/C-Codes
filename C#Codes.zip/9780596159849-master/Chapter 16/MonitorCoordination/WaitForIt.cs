﻿using System.Threading;

namespace MonitorCoordination
{
    // Example 16-14. Coordinating threads with Monitor
    class WaitForIt
    {
        private bool canGo;
        private object lockObject = new object();
        public void WaitUntilReady()
        {
            lock (lockObject)
            {
                while (!canGo)
                {
                    Monitor.Wait(lockObject);
                }
            }
        }
        public void GoNow()
        {
            lock (lockObject)
            {
                canGo = true;
                // Wake me up, before you go go.
                Monitor.PulseAll(lockObject);
            }
        }
    }
}
