﻿using System;
using System.Threading.Tasks;

namespace TplExamples
{
    class Program
    {
        // Example 16-19. Task.WaitAll
        static void Main(string[] args)
        {
            Task t1 = Task.Factory.StartNew(() => Go("One", 100));
            Task t2 = Task.Factory.StartNew(() => Go("Two", 500));

            Task.WaitAll(t1, t2);
        }

        static void Go(string name, int iterations)
        {
            for (int i = 0; i < iterations; ++i)
            {
                Console.WriteLine("{0}: {1}", name, i);
            }
        }
    }
}