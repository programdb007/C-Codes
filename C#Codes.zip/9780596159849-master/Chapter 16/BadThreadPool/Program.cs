﻿using System;
using System.Threading;

namespace BadThreadPool
{
    class Program
    {
        // Example 16-6. Queuing work items for the thread pool
        static void Main(string[] args)
        {
            ThreadPool.QueueUserWorkItem(Go, "One");
            ThreadPool.QueueUserWorkItem(Go, "Two");
            Go("Main");
            // Problem: not waiting for work items to complete!
        }

        static void Go(object name)
        {

            for (int i = 0; i < 100; ++i)
            {
                Console.WriteLine("{0}: {1}", name, i);
            }
        }
    }
}
