﻿using System;

namespace ProgrammingCSharpWeb
{
    public partial class DisplayShippers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rblShippers.SelectedIndex = 0;
            }
        }
        protected void btnOrder_Click(object sender, EventArgs e)
        {
            lblMsg.Text = "Thank you " + txtName.Text.Trim() +
            ". You chose " + rblShippers.SelectedItem.Text +
            " whose ID is " + rblShippers.SelectedValue;
        }
    }
}