﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace LapAnalysis
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 2-13. Fastest lap including lap number
            string[] lines = File.ReadAllLines("LapTimes.txt");
            double currentLapStartTime = 0;
            double fastestLapTime = 0;
            int lapNumber = 1;
            int fastestLapNumber = 0;
            foreach (string line in lines)
            {
                double lapEndTime = double.Parse(line);
                double lapTime = lapEndTime - currentLapStartTime;
                if (fastestLapTime == 0 || lapTime < fastestLapTime)
                {
                    fastestLapTime = lapTime;
                    fastestLapNumber = lapNumber;
                }
                currentLapStartTime = lapEndTime;
                lapNumber += 1;
            }
            Console.WriteLine("Fastest lap: " + fastestLapNumber);
            Console.WriteLine("Fastest lap time: " + fastestLapTime);
        }
    }
}
