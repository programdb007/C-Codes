﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RaceInfo
{
    class Program
    {
        // Example 2-5. Variables
        static void Main(string[] args)
        {
            double kmTravelled = 5.14;
            double elapsedSeconds = 78.74;
            double fuelKilosConsumed = 2.7;
        }
    }
}
