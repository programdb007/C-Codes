﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleForLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 2-14. Counting with a for loop
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("Coming, ready or not!");
        }
    }
}
