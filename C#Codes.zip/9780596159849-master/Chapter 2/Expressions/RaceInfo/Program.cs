﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RaceInfo
{
    class Program
    {
        static void Main(string[] args)
        {
            double kmTravelled = 5.14;
            double elapsedSeconds = 78.74;
            double fuelKilosConsumed = 2.7;

            Console.WriteLine(
                // Example 2-6. Dividing one variable by another
                kmTravelled / fuelKilosConsumed
                );

            Console.WriteLine(
                // Example 2-7. Dividing one literal by another
                60 / 10
                );
        }
    }
}
