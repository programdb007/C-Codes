﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RaceInfo
{
    class Program
    {
        // Example 2-8. Reading command-line inputs
        static void Main(string[] args)
        {
            double kmTravelled = double.Parse(args[0]);
            double elapsedSeconds = double.Parse(args[1]);
            double fuelKilosConsumed = double.Parse(args[2]);
        }
    }
}
