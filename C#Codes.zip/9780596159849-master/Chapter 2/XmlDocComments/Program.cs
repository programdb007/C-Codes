﻿using System;

namespace XmlDocComments
{
    class Program
    {
        // Example 2-4. XML documentation comments

        /// <summary>
        /// Returns the square of the specified number.
        /// </summary>
        /// <param name="x">The number to square.</param>
        /// <returns>The squared value.</returns>
        static double Square(double x)
        {
            return x * x;
        }

        static void Main(string[] args)
        {
            Console.WriteLine(Square(16));
        }
    }
}
