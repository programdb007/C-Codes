﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RaceInfo
{
    // Fake class used in examples that illustrate how flow control
    // code can look.
    class Driver
    {
        internal static void TellNotToOvertake()
        {
        }

        internal static void WarnAboutSafetyCar()
        {
        }

        internal static void ReducePay()
        {
        }

        internal static void Resuscitate()
        {
        }

        internal static void CallBackToPit()
        {
        }

        internal static void TellToDriveFaster()
        {
        }
    }
}
