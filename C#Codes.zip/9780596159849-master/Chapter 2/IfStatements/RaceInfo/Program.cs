﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RaceInfo
{
    class Program
    {
        static void Main(string[] args)
        {
            double kmTravelled = double.Parse(args[0]);
            double elapsedSeconds = double.Parse(args[1]);
            double fuelKilosConsumed = double.Parse(args[2]);

            // Example 2-9. If statement
            double fuelTankCapacityKilos = 80;
            double lapLength = 5.141;

            double fuelKilosPerKm = fuelKilosConsumed / kmTravelled;
            double fuelKilosRemaining = fuelTankCapacityKilos - fuelKilosConsumed;
            double predictedDistanceUntilOutOfFuel = fuelKilosRemaining / fuelKilosPerKm;
            double predictedLapsUntilOutOfFuel =
                predictedDistanceUntilOutOfFuel / lapLength;

            if (predictedLapsUntilOutOfFuel < 4)
            {
                Console.WriteLine("Low on fuel. Laps remaining: " +
                predictedLapsUntilOutOfFuel);
            }


            // Variables required to get Example 2-10 to compile.
            // In a real app, these would typically come from inputs
            // to the program or a database. Clearly this particular
            // example isn't totlaly realistic.
            bool ourDriverCausedIncident = false;
            bool feelingGenerous = true;


            // Example 2-10. Testing multiple conditions with if and else
            string raceStatus = args[3];
            if (raceStatus == "YellowFlag")
            {
                Driver.TellNotToOvertake();
            }
            else if (raceStatus == "SafetyCar")
            {
                Driver.WarnAboutSafetyCar();
            }
            else if (raceStatus == "RedFlag")
            {
                if (ourDriverCausedIncident)
                {
                    Factory.OrderNewCar();
                    Driver.ReducePay();
                    if (feelingGenerous)
                    {
                        Driver.Resuscitate();
                    }
                }
                else
                {
                    Driver.CallBackToPit();
                }
            }
            else
            {
                Driver.TellToDriveFaster();
            }
        }
    }
}
