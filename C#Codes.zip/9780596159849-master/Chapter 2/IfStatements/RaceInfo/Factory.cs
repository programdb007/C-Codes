﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RaceInfo
{
    // Fake class used in examples that illustrate how flow control
    // code can look.
    class Factory
    {
        internal static void OrderNewCar()
        {
        }
    }
}
