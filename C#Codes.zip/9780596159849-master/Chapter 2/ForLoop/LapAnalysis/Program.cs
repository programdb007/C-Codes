﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace LapAnalysis
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 2-15. Finding the fastest lap with for
            string[] lines = File.ReadAllLines("LapTimes.txt");
            double currentLapStartTime = 0;
            double fastestLapTime = 0;
            int fastestLapNumber = 0;
            for (int lapNumber = 1; lapNumber <= lines.Length; lapNumber++)
            {
                double lapEndTime = double.Parse(lines[lapNumber - 1]);
                double lapTime = lapEndTime - currentLapStartTime;
                if (fastestLapTime == 0 || lapTime < fastestLapTime)
                {
                    fastestLapTime = lapTime;
                    fastestLapNumber = lapNumber;
                }
                currentLapStartTime = lapEndTime;
            }
            Console.WriteLine("Fastest lap: " + fastestLapNumber);
            Console.WriteLine("Fastest lap time: " + fastestLapTime);
        }
    }
}
