﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace WhileLoop
{
    class Program
    {
        // Example 2-16. Iterating through a file with a while loop
        static void Main(string[] args)
        {
            using (StreamReader times = File.OpenText("LapTimes.txt"))
            {
                while (!times.EndOfStream)
                {
                    string line = times.ReadLine();
                    double lapEndTime = double.Parse(line);
                    Console.WriteLine(lapEndTime);
                }
            }
        }
    }
}
