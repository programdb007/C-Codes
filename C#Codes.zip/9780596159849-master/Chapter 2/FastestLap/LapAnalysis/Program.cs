﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace LapAnalysis
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 2-12. Finding the fastest lap with foreach
            string[] lines = File.ReadAllLines("LapTimes.txt");
            double currentLapStartTime = 0;
            double fastestLapTime = 0;
            foreach (string line in lines)
            {
                double lapEndTime = double.Parse(line);
                double lapTime = lapEndTime - currentLapStartTime;
                if (fastestLapTime == 0 || lapTime < fastestLapTime)
                {
                    fastestLapTime = lapTime;
                }
                currentLapStartTime = lapEndTime;
            }
            Console.WriteLine("Fastest lap time: " + fastestLapTime);
        }
    }
}
