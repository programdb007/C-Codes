﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace NonInteropDynamic
{
    class Static
    {
        // Example 18-21. A simple filter
        static bool Test(int x)
        {
            return x < 100;
        }

        public static void Test()
        {
            // Example 18-22. Filtering with LINQ
            var nums = Enumerable.Range(1, 200);
            var filteredNumbers = nums.Where(Test);
        }
    }

    class Dynamic
    {
        // Example 18-23. A dynamic filter
        static bool Test(dynamic x)
        {
            return x < 100;
        }

        // Example 18-25. A dynamic-friendly Where implementation
        static IEnumerable<T> DynamicWhere<T>(IEnumerable<T> input, dynamic test)
        {
            foreach (T item in input)
            {
                if (test(item))
                {
                    yield return item;
                }
            }
        }

        public static void Test()
        {
            var nums = Enumerable.Range(1, 200);

            {
                // Example 18-24. Making a dynamic filter palatable for LINQ
                var filteredNumbers = nums.Where(x => Test(x));
            }


            // Change this to true to see Example 18-26 fail to compile.
#if false
            {
                // Example 18-26. Attempting (and failing) to call DynamicWhere
                var filteredNumbers = DynamicWhere(nums, Test); // Compiler error
            }
#else
            {
                // Example 18-27. Giving DynamicWhere a clue
                var filteredNumbers = DynamicWhere(nums, (Predicate<dynamic>) Test);
            }
#endif
        }
    }

    class Program
    {

        static void Main(string[] args)
        {
            Static.Test();
            Dynamic.Test();
        }
    }
}
