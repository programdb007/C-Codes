﻿using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        // Example 18-15. Replacing IEnumerable<int> with dynamic
        dynamic numbers = Enumerable.Range(1, 10);

        // Will fail at runtime.
        int total = numbers.Sum();

        // The next example doesn't even compile (for reasons explained
        // in the book). Set this false to true to see the error.
#if false
        // Example 18-16. Lambdas and types
        int total = numbers.Sum(x => x * x);
#endif
    }
}