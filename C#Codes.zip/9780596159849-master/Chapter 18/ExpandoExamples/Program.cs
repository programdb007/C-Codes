﻿using System;
using System.Collections.Generic;
using System.Dynamic;

namespace ExpandoExamples
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 18-17. Setting dynamic properties
            dynamic dx = new ExpandoObject();
            dx.MyProperty = true;
            dx.AnotherProperty = 42;

            // Example 18-18. Iterating through dynamic properties
            foreach (KeyValuePair<string, object> prop in dx)
            {
                Console.WriteLine(prop.Key + ": " + prop.Value);
            }

            // Example 18-19. ExpandoObject as both dictionary and dynamic object
            ExpandoObject xo = new ExpandoObject();
            IDictionary<string, object> dictionary = xo;
            dictionary["Foo"] = "Bar";
            dynamic dyn = xo;
            Console.WriteLine(dyn.Foo);
        }
    }
}
