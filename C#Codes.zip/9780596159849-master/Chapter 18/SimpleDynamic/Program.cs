﻿using System;

namespace SimpleDynamic
{
    class Program
    {
        // Example 18-4. Using dynamic
        static dynamic AddAnything(dynamic a, dynamic b)
        {
            dynamic result = a + b;
            Console.WriteLine(result);
            return result;
        }

        static void Main(string[] args)
        {
            // Example 18-5. Passing different types
            Console.WriteLine(AddAnything("Hello", "world").GetType().Name);
            Console.WriteLine(AddAnything(31, 11).GetType().Name);
            Console.WriteLine(AddAnything("31", 11).GetType().Name);
            Console.WriteLine(AddAnything(31, 11.5).GetType().Name);
        }
    }
}

