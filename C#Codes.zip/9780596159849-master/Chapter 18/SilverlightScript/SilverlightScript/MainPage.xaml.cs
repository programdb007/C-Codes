﻿using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;

namespace SilverlightScript
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OldClick(object sender, RoutedEventArgs e)
        {
            // Example 18-8. Accessing JavaScript in C# 3.0
            ScriptObject showMessage = (ScriptObject)
                HtmlPage.Window.GetProperty("showMessage");
            showMessage.InvokeSelf("Hello, world");

            // Or...

            ScriptObject window = HtmlPage.Window;
            window.Invoke("showMessage", "Hello, world");
        }

        private void NewClick(object sender, RoutedEventArgs e)
        {
            // Example 18-9. Accessing JavaScript in C# 4.0
            dynamic window = HtmlPage.Window;
            window.showMessage("Hello, world");
        }
    }
}
