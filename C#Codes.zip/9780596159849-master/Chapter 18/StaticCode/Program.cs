﻿using System;

namespace StaticCode
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 18-1. Simple code with various static features
            var myString = Console.ReadLine();
            var modifiedString = myString.Replace("color", "colour");
        }
    }
}
