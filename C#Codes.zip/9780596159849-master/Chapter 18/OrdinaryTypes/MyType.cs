﻿
namespace OrdinaryTypes
{
    // Example 18-10. A simple class
    class MyType
    {
        public string Text { get; set; }
        public int Number { get; set; }
        public override string ToString()
        {
            return Text + ", " + Number;
        }
        public void SetBoth(string t, int n)
        {
            Text = t;
            Number = n;
        }
        public static MyType operator +(MyType left, MyType right)
        {
            return new MyType
            {
                Text = left.Text + right.Text,
                Number = left.Number + right.Number
            };
        }
    }
}
