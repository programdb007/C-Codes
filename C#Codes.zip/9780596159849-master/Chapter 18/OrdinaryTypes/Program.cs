﻿using System;
using Microsoft.CSharp.RuntimeBinder;

namespace OrdinaryTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Example 18-11. Using a simple object with dynamic
                dynamic a = new MyType { Text = "One", Number = 123 };
                Console.WriteLine(a.Text);
                Console.WriteLine(a.Number);
                Console.WriteLine(a.Problem);
            }
            catch (RuntimeBinderException)
            {
                Console.WriteLine("Exception thrown as expected");
            }

            {
                // Example 18-12. Setting properties and calling methods with dynamic
                dynamic a = new MyType();
                a.Number = 42;
                a.Text = "Foo";
                Console.WriteLine(a);
                dynamic b = new MyType();
                b.SetBoth("Bar", 99);
                Console.WriteLine(b);

                // Example 18-13. Using an overloaded + operator
                MyType c = AddAnything(a, b);
                Console.WriteLine(c);
            }
        }

        static dynamic AddAnything(dynamic a, dynamic b)
        {
            dynamic result = a + b;
            Console.WriteLine(result);
            return result;
        }
    }
}
