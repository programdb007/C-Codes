﻿using System;
using Microsoft.CSharp.RuntimeBinder;

namespace Custom
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                dynamic cd = new CustomDynamic();
                Console.WriteLine(cd.Brigadoon);
            }
            catch (RuntimeBinderException)
            {
                Console.WriteLine("Brigadoon not visible today.");
            }
        }
    }
}
