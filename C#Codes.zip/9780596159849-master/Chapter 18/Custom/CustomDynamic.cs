﻿using System;
using System.Dynamic;

public class CustomDynamic : DynamicObject
{
    private static DateTime FirstSighting = new DateTime(1947, 3, 13);

    public override bool TryGetMember(GetMemberBinder binder,
                                      out object result)
    {
        var compare = binder.IgnoreCase ?
            StringComparer.InvariantCultureIgnoreCase :
            StringComparer.InvariantCulture;
        if (compare.Compare(binder.Name, "Brigadoon") == 0)
        {
            // Brigadoon famous for appearing only once every hundred years.
            DateTime today = DateTime.Now.Date;
            if (today.DayOfYear == FirstSighting.DayOfYear)
            {
                // Right day, what about the year?
                int yearsSinceFirstSighting = today.Year - FirstSighting.Year;
                if (yearsSinceFirstSighting % 100 == 0)
                {
                    result = "Welcome to Brigadoon. Please drive carefully.";
                    return true;
                }
            }
        }
        return base.TryGetMember(binder, out result);
    }
}