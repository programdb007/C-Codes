﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Interop.Word;

namespace OptionalRef
{
    class Program
    {
        static void Main(string[] args)
        {
            Application wordApp = new Application();
            wordApp.ChangeFileOpenDirectory(Environment.CurrentDirectory);

            {
                // Example 19-4. Ugliness by reference
                object fileName = @"WordFile.docx";
                object missing = System.Reflection.Missing.Value;
                object readOnly = true;
                var doc = wordApp.Documents.Open(ref fileName, ref missing, ref readOnly,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing);


                ((_Document) doc).Close();
            }

            wordApp.ChangeFileOpenDirectory(Environment.CurrentDirectory);
            {
                object fileName = @"WordFile.docx";
                object missing = System.Reflection.Missing.Value;
                object readOnly = true;

                // Example 19-5. Omitting ref
                var doc = wordApp.Documents.Open(fileName, missing, readOnly,
                    missing, missing, missing, missing, missing,
                    missing, missing, missing, missing, missing,
                    missing, missing, missing);


                ((_Document) doc).Close();
            }

            wordApp.ChangeFileOpenDirectory(Environment.CurrentDirectory);
            {
                object fileName = @"WordFile.docx";
                object missing = System.Reflection.Missing.Value;
                object readOnly = true;

                // Example 19-6. Optional arguments
                var doc = wordApp.Documents.Open(FileName: fileName, ReadOnly: readOnly);


                ((_Document) doc).Close();
            }
        }
    }
}
