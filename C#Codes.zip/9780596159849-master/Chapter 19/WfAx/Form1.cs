﻿using System.Windows.Forms;

namespace WfAx
{
    public partial class Form1 : Form
    {
        // Example 19-1. Setting a property on the control
        public Form1()
        {
            InitializeComponent();
            string pdf = "http://www.interact-sw.co.uk/downloads/ExamplePdf.pdf";
            pdfAxCtl.src = pdf;
        }
    }
}
