﻿using System;
using System.IO;
using System.Xml.Serialization;

namespace Programming_CSharp
{
    // Simple customer class
    public class Customer
    {
        [XmlAttribute]
        public string FirstName { get; set; }

        [XmlIgnore]
        public string LastName { get; set; }

        public string EmailAddress { get; set; }

        // Overrides the Object.ToString() to provide a
        // string representation of the object properties.
        public override string ToString()
        {
            return string.Format("{0} {1}\nEmail: {2}",
                FirstName, LastName, EmailAddress);
        }
    }

    // Main program
    public class Tester
    {
        static void Main()
        {
            Customer c1 = new Customer
            {
                FirstName = "Orlando",
                LastName = "Gee",
                EmailAddress = "orlando0@hotmail.com"
            };

            //XmlSerializer serializer = new XmlSerializer(c1.GetType());
            XmlSerializer serializer = new XmlSerializer(typeof(Customer));
            StringWriter writer = new StringWriter();

            serializer.Serialize(writer, c1);
            string xml = writer.ToString();
            Console.WriteLine("Customer in XML:\n{0}\n", xml);

            Customer c2 = serializer.Deserialize(new StringReader(xml)) as Customer;
            Console.WriteLine("Customer in Object:\n{0}", c2.ToString());

            Console.ReadKey();
        }
    }
}