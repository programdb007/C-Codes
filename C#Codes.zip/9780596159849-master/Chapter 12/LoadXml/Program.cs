﻿using System;
using System.Xml.Linq;

namespace LoadXml
{
    class Program
    {
        static void Main(string[] args)
        {
            // Example 12-2. Loading XML from a string
            XDocument doc = XDocument.Parse("<Customers><Customer /></Customers>");

            Console.WriteLine(doc);
        }
    }
}
