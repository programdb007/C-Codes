﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AirTrafficControl
{
    class Program
    {
        static void Main(string[] args)
        {
            Plane someBoeing777 = new Plane("BA0049");

            someBoeing777.SpeedInMilesPerHour = 400.0;
            someBoeing777.SpeedInMilesPerHour = 380.0;

            Console.ReadKey();
        }
    }
}
