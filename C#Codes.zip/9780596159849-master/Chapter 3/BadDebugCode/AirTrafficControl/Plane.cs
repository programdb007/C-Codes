﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Plane
{
    // Constructor with a parameter
    public Plane(string newIdentifier)
    {
        Identifier = newIdentifier;
    }

    public string Identifier
    {
        get;
        private set;
    }

    const double kilometersPerMile = 1.609344;

    // Example 3-15. Badly written debugging code
    public double SpeedInMilesPerHour
    {
        get
        {
            return SpeedInKilometersPerHour / kilometersPerMile;
        }
        set
        {
            Identifier += ": speed modified to " + value;
            Console.WriteLine(Identifier);
            SpeedInKilometersPerHour = value * kilometersPerMile;
        }
    }

    public double SpeedInKilometersPerHour
    {
        get;
        set;
    }
}