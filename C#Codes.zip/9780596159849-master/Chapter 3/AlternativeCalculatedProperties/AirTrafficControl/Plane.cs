﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Plane
{
    public Plane(string newIdentifier)
    {
        Identifier = newIdentifier;
    }

    public string Identifier
    {
        get;
        private set;
    }

    // Example 3-10. Swapping over the real and calculated properties
    public double SpeedInMilesPerHour
    {
        get
        {
            return SpeedInKilometersPerHour / 1.609344;
        }
        set
        {
            SpeedInKilometersPerHour = value * 1.609344;
        }
    }
    public double SpeedInKilometersPerHour
    {
        get;
        set;
    }
}
