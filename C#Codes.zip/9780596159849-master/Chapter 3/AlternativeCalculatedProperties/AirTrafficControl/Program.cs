﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AirTrafficControl
{
    class Program
    {
        // Example 3-11. Using the speed properties
        static void Main(string[] args)
        {
            Plane someBoeing777 = new Plane("BA0049");
            someBoeing777.SpeedInMilesPerHour = 150.0;

            Console.WriteLine(
                "Your plane has identifier {0}, " +
                "and is traveling at {1:0.00}mph [{2:0.00}kph]",
                someBoeing777.Identifier,
                someBoeing777.SpeedInMilesPerHour,
                someBoeing777.SpeedInKilometersPerHour);

            someBoeing777.SpeedInKilometersPerHour = 140.0;

            Console.WriteLine(
                "Your plane has identifier {0}, " +
                "and is traveling at {1:0.00}mph [{2:0.00}kph]",
                someBoeing777.Identifier,
                someBoeing777.SpeedInMilesPerHour,
                someBoeing777.SpeedInKilometersPerHour);

            Console.ReadKey();
        }
    }
}
