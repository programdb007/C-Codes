﻿using System;

namespace ToDoList
{
    // Example 22-1. Class representing to-do list entries
    public class ToDoEntry
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
    }
}
