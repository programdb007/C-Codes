﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

public class AdminPage
{
    public global::ItemEditPage ItemEditPage
    {
        get
        {
            throw new System.NotImplementedException();
        }
        set
        {
        }
    }
}
