﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class ItemEditPage : System.Web.UI.Page
{
    SqlConnection myconn;
    protected void Page_Load(object sender, EventArgs e)
    {
        myconn= new SqlConnection();
        myconn.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;User Instance=True";
    }
    public void insertItem_Table()
    {
        myconn.Open();
        SqlCommand MyCmd = new SqlCommand();
        MyCmd.CommandType = CommandType.Text;
        MyCmd.Connection = myconn;
        MyCmd.CommandText = "INSERT INTO Item_Table VALUES('" +txt_cmpntID.Text +"','"+ txt_cmpntName.Text + "','" + txt_type.Text + "'," + int.Parse(txt_price.Text) + "," + int.Parse(txt_supID.Text)+ ")";
        MyCmd.ExecuteNonQuery();
        myconn.Close();

    }

    protected void btn_save_Click(object sender, EventArgs e)
    {
        try
        {
            insertItem_Table();
        }
        catch (Exception ee)
        { Response.Write("Insertation Error"); }

        Response.Write("Completely Added");
        SqlDataSource2.SelectCommand = "SELECT ComponentID from Item_Table";

    }
    protected void btn_update_Click(object sender, EventArgs e)
    {
        try
        {
            myconn.Open();
            SqlCommand MyCmd = new SqlCommand();
            MyCmd.CommandType = CommandType.Text;
            MyCmd.Connection = myconn;
            MyCmd.CommandText = "UPDATE Item_Table SET Type='" + txt_type.Text + "', Price=" + int.Parse(txt_price.Text) + ",SupplierID =" + int.Parse(txt_supID.Text) + " WHERE ComponentID=" + int.Parse(lstComponentID.SelectedItem.Value);
            MyCmd.ExecuteNonQuery();
            myconn.Close();
        }
        catch(Exception ee){Response.Write("Error update");}
        Response.Write("Update succeeded");
    }

    protected void btn_delete_Click(object sender, EventArgs e)
    {
        try
        {
            myconn.Open();
            SqlCommand mycmd = new SqlCommand();
            mycmd.CommandType = CommandType.Text;
            mycmd.Connection = myconn;
            mycmd.CommandText = "delete from Item_Table WHERE ComponentID=" + int.Parse(lstComponentID.SelectedItem.Value);

            mycmd.ExecuteNonQuery();
            myconn.Close();
        }
        catch (Exception error) { Response.Write("Delete error"); }
        Response.Write("Item deleted");
        SqlDataSource2.SelectCommand = "SELECT ComponentID from Item_Table";
        
        
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        myconn.Open();
        SqlCommand MyCmd = new SqlCommand();
        MyCmd.CommandType = CommandType.Text;
        MyCmd.Connection = myconn;
        MyCmd.CommandText = "SELECT * FROM Item_Table WHERE ComponentID=" + int.Parse(lstComponentID.SelectedItem.Value);
        SqlDataReader reader;
        reader = MyCmd.ExecuteReader();
        while (reader.Read())
        {
            txt_cmpntID.Text = reader.GetValue(0).ToString();
            txt_cmpntName.Text = reader.GetValue(1).ToString();
            txt_type.Text = reader.GetValue(2).ToString();
            txt_price.Text = reader.GetValue(3).ToString();
            txt_supID.Text = reader.GetValue(4).ToString();

        }
        reader.Close();
        myconn.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        myconn.Open();
        SqlCommand MyCmd = new SqlCommand();
        MyCmd.CommandType = CommandType.Text;
        MyCmd.Connection = myconn;
        MyCmd.CommandText = "SELECT MAX(ComponentID) FROM Item_Table";
        SqlDataReader reader;
        reader = MyCmd.ExecuteReader();
        while (reader.Read())
        {
            txt_cmpntID.Text = (int.Parse(reader.GetValue(0).ToString()) + 1).ToString();

        }
        reader.Close();
        myconn.Close();

        txt_cmpntName.Text = null;
        txt_type.Text = null;
        txt_price.Text = null;
        txt_supID.Text = null;


    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowItemData.aspx");
    }
    protected void SqlDataSource2_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
}